$(window).on("load", inicio);

function inicio(){


  let inicial={
        method:"POST",
        headers:{"Content-Type":"application/json"}
        //body: datos
    }
    fetch("php/ejercicio6a.php", inicial)
        .then(correctoObtenerDatos)
        .catch(errorObtenerDatos);



  //$.ajax("php/ejercicio5a.php",{success:obtenerDatos});
  
  let formulario = $("#formulario");
  $(formulario).on("change",obtenerDatos);
}

function correctoObtenerDatos(response){
    if (response.ok) {
        response.json().then(mostrarLista)
    }
}

function errorObtenerDatos()
{
    $("#marcas").append("<option>Error</option>");
}

function mostrarLista(dato)
{
  console.log(dato);
  for (var i = 0; i < dato.marcas.length; i++) {
    $("#marcas").append("<option>"+dato.marcas[i]+"</option>");
  }
}




function obtenerDatos(){
  let marca = $("#marcas").val();
  let elec = $("#electrodomestico").val();
let recogidos ={
  "marca": marca,
  "elec": elec
};

let enviar=JSON.stringify(recogidos);
console.log(enviar);
  let inicial={
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: enviar,
      cache: "no-cache"
    }
    fetch("php/ejercicio6b.php", inicial)
        .then(correcto)
        .catch(error);
};

function correcto(response){
  if (response.ok) {
        response.json().then(mostrarDatos);
  }
}

function error(event)
{
  console.log(event);
    $("#ancho").val("Error");
    $("#alto").val("Error");
    $("#fondo").val("Error");
}

function mostrarDatos(dato)
{
  console.log(dato);
  $("#ancho").val(dato.ancho);
  $("#alto").val(dato.alto);
  $("#fondo").val(dato.fondo);
}