$(window).on("load",inicio);
 function inicio(){

    if(document.readyState=="complete"){
        $("#enviar").on("click",enviarDatos);
    }
}

var solicitud;
function enviarDatos(){
    if(window.XMLHttpRequest)
        solicitud= new XMLHttpRequest();
    else if(window.ActiveXObject)
        solicitud= new ActiveXObject("Microsoft.XMLHTTP");

    let nombre=$("#nombre").val();
    let apellido=$("#apellidos").val();
    let trabajo=$("#trabajo").val();

    let datos= new FormData();
    datos.append("nombre", nombre);
    datos.append("apellidos", apellido);
    datos.append("trabajo",trabajo);
    $(peticion_http).on('readystatechange', mostrar);

        solicitud.open("POST", "php/ejercicio4.php");
        solicitud.send(datos);
}

function mostrar(){
    if (solicitud.readyState==4) 
        if (solicitud.status==200)
            //document.getElementById("sueldo").value=solicitud.responseText;
            $("#sueldo").val(peticion_http.responseText);
}