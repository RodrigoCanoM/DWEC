var peticion_http;
var peticion_http2;
$(window).on("load", inicio);

function inicio(){
  $.ajax("php/ejercicio5a.php",{success:obtenerDatos});
  let formulario = $("#formulario");
  $(formulario).on("change",obtenerPrecio);

}
function obtenerDatos(valor){
  let marca=$(valor).find("marca");
  for (let i=0;i < $(marca).length;i++)
    $("#marca").append("<option>"+$(marca).eq(i).text()+"</option>");

  let medida=$(valor).find("medida");
  for (let i=0;i < $(medida).length;i++)
    $("#medida").append("<option>"+$(medida).eq(i).text()+"</option>");
}

function obtenerPrecio(){
  var marca = $("#marca").val();
  var medida = $("#medida").val().split(" ", 1);
  var cadena =
    "<televisores><marca>" +
    marca +
    "</marca><medida>" +
    medida +
    "</medida></televisores>";

    if (window.XMLHttpRequest){
      peticion_http2 =new XMLHttpRequest();
    }else if (window.ActiveXObject){
      try{
        peticion_http2 =new ActiveXObject("Microsoft.XMLHTTP");
      }catch(e){
       return false;
      }
    }
  $(peticion_http2).on('readystatechange', mostrarPrecio);

  peticion_http2.open("POST", "php/ejercicio5b.php", true);
  peticion_http2.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
  peticion_http2.setRequestHeader("Content-Length", cadena.length);
  peticion_http2.send(cadena);
};

function mostrarPrecio() {
  if (peticion_http2.readyState == 4 && peticion_http2.status == 200) {
    $("#precio").val(peticion_http2.responseText + " €");
  }
};
