$(window).on("load",inicio);
var peticion_http;
var nombre;
var apellido;
var modulo;
var nota;
//var textNota;

function inicio(){
    if(document.readyState=="complete"){
        $("#enviar").on("click",peticion);
    }
}

function peticion(){
    nombre=$("#nombre").val();
    apellido=$("#apellidos").val();
    modulo=$("#modulo").val();
    nota=$("#nota").val();
    //textNota=$("#texto");
    if(nombre !="" && apellido!="" && modulo !="" && nota>=0 && nota<=10){
        nombre.disabled=true;
        apellido.disabled=true;
        modulo.disabled=true;
        nota.disabled=true;
        if(window.XMLHttpRequest){
            peticion_http= new XMLHttpRequest();
        }else if(window.ActiveXObject){
            peticion_http= new ActiveXObject("Microsoft.XMLHTTP");
        }
        $(peticion_http).on('readystatechange', respuesta);

            peticion_http.open("POST", "php/ejercicio3.php", true);
            peticion_http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            peticion_http.send("nombre="+nombre+"&apellidos="+apellido+"&modulo="+modulo+"&nota="+nota );
    }else{
        alert("Rellena todos los campos y la nota es de 0 a 10");
    }
}

function respuesta(evento){
    if (evento.target.readyState == 4 && evento.target.status == 200) {
        nombre.disabled=false;
        apellido.disabled=false;
        modulo.disabled=false;
        nota.disabled=false;
        //textNota.value=evento.target.responseText;
        $("#texto").val(peticion_http.responseText);
    }
}