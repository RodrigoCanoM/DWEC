<?php
$nombre = $apellido = $trabajo = "";
$nombre=$_REQUEST["nombre"];
$apellido=$_REQUEST["apellidos"];
$trabajo=$_REQUEST["trabajo"];
$sueldo=rand(1000, 3250);
echo $sueldo;
?>