<?php
$nombre = $apellido = $modulo = "";
$nombre=$_REQUEST["nombre"];
$apellido=$_REQUEST["apellidos"];
$modulo=$_REQUEST["modulo"];
if ($nombre!="" && $apellido!="" && $modulo!="")
    echo rand(4,10);

?>