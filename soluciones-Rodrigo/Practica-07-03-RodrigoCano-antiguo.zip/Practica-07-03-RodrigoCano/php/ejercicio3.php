<?php
$nombre = $apellido = $modulo = "";
$nota=-1;
$nombre=$_REQUEST["nombre"];
$apellido=$_REQUEST["apellidos"];
$modulo=$_REQUEST["modulo"];
$nota=$_REQUEST["nota"];

if ($nombre!="" && $apellido!="" && $modulo!="" && $nota>=0){

	if($nota<5)
		echo "SUSPENSO";
	elseif($nota==5)
		echo "SUFICIENTE";
	elseif($nota==6)
		echo "BIEN";
	elseif ($nota==7 || $nota==8)
		echo "NOTABLE";
	elseif($nota==9 || $nota==10)
		echo "SOBRESALIENTE";
}
else echo "ERROR";
?>