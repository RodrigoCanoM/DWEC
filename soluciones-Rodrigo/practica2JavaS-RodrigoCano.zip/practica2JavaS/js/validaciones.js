window.onload=cargado;
function cargado(){
    document.primero.provincia.onkeypress=soloR;
    document.primero.provincia.onchange=soloR;
    document.primero.cp.onchange=codigoPostal;
    document.primero.onsubmit=enviar;
}
function soloR() {
	document.primero.provincia.value=codigoPostal();
	return false
	
}

function enviar() 
{
	
	var mensaje="";
	//alert(mensaje.length);
	var cadena=document.primero.nombre.value.toString().toUpperCase();
	
	let SocApNom=/^[A-Z][A-Z\dªº\-\. ]+[A-Z\d.]$/i;
	if (!SocApNom.test(cadena))
		mensaje+="Error: Razón Social/Apellidos y Nombre  \n";
	let codEmp=/^[A-Z\d]{5,10}$/i;
	cadena=document.primero.codigo.value.toString().toUpperCase();
	if (!codEmp.test(cadena))
		mensaje+="Error: Codigo de Empresa \n";
	cadena=nif_cif();
	
	let errorCifNif=/^(([CN]2)|0)$/i;
	if (errorCifNif.test(cadena))
	{
		if (cadena=="C2")
		mensaje+="Error: Se ha introducido un cif erróneo. El carácter de control es erróneo. \n";
		else if (cadena=="N2")
		mensaje+="Error: Se ha introducido un NIF erróneo. El carácter de control es erróneo. \n";
		else mensaje+="Error: Se ha introducido un dato no válido. No es CIF. \n";
	}
	let direccion=/^[A-Z][A-Z\dªº\-\/\. ]+[A-Z\d]$/i;
	cadena=document.primero.direccion.value.toString().toUpperCase();
	if (!direccion.test(cadena))
		mensaje+="Error: Direccion \n";
	
	let localidad=/^[A-Z][A-Z ]+[A-Z]$/i;
	cadena=document.primero.localidad.value.toString().toUpperCase();
	if(!localidad.test(cadena))
		mensaje+="Error: Localidad \n";
	
	let cp=/^(([1-4][0-9]{2,3}[1-9])|([5][0-2][0-9]{2}[0-8]))$/i;
	cadena=document.primero.cp.value.toString().toUpperCase();
	if (!cp.test(cadena))
		mensaje+="Error: Codigo Postal \n";
	
	codigoPostal();
	
	let telefonoFax=/^(([967][0-9]{8})|([9][0-9]{8}))$/;
	cadena=document.primero.telefono.value.toString();
	
	if (!telefonoFax.test(cadena))
		mensaje+="Error: Telefono o Fax \n";
	
	let fechaFun=/^([\d]?\d)\/([\d]?\d)\/((\d\d)?\d\d)$/;
	cadena=document.primero.fConstitucionEmp.value.toString();
	
	if (!fechaFun.test(cadena))
		mensaje+="Error: Fecha de Constitución de la Empresa \n";
	
	
	let cBanco=document.primero.cBanco.value.toString();
	let cCodigo=/^[0-9]{4}$/;
	if (!cCodigo.test(cBanco))
		mensaje+="Error: Codigo del Banco \n";
	let cOficina=document.primero.cOficina.value.toString();		
	if (!cCodigo.test(cOficina))
		mensaje+="Error: Codigo de la oficina \n";
	let nCuenta=/^[0-9]{10}$/;
	let cCuenta=document.primero.nCuenta.value.toString();
	if (!nCuenta.test(cCuenta))
		mensaje+="Error: Numero de cuenta \n";
	let cControl=document.primero.cControl.value.toString();
	
	let cCont=/^[0-9]{2}$/;	
	if (!cCont.test(cControl))
		mensaje+="Error: Codigo de Control, debe ser dos numeros \n";
	else if (cCodigo.test(cBanco) && cCodigo.test(cOficina) && nCuenta.test(cCuenta))
		{
			let controlF=codigosControl(cBanco,cOficina,cCuenta);
			if (!(controlF==cControl))
				mensaje+="Error: Codigo de Control incorrecto \n";
			else {
				let IBANE=calculoIBANEspanya(cBanco+cOficina+cControl+cCuenta);
				if (!comprobarIBAN(IBANE))
					mensaje+="El IBAN resultante de España es incorrecto \n"
				
			}
		}
	let IBAN=document.primero.IBAN.value.toString();
	let formatoIBAN=/^[A-Z]{2}[0-9]+$/;
	alert(IBAN);
	if(!formatoIBAN.test(IBAN))
		mensaje+="Error: IBAN no corresponde al formato \n"
	else if (!comprobarIBAN(IBAN))
		mensaje+="Error: el IBAN es incorrecto \n";
	
	alert(mensaje);
	if (mensaje.length>0)
		return false;
	else return true;
	
}
function codigoPostal() 
{
	var x = document.primero.cp.value;
	var provincias = ['Alava','Albacete','Alicante','Almeria','Avila','Badajoz','Islas Baleares','Barcelona','Burgos','Caceres','Cadiz',						'Castellon','Ciudad Real','Cordoba',
					'La Coruña','Cuenca','Gerona','Granada','Gualdajara','Guipúzcoa','Huelva','Huesca','Jaén','León','Lérida','La Rioja','Lugo','Madrid','Málaga','Murcia',
					'Navarra','Orense','Asturias','Palencia','Las Palmas','Pontevedra','Salamanca','Santa Cruz de Tenerife','Cantabria','Segovia','Sevilla','Soria','Tarragona',
					'Teruel','Toledo','Valencia','Valladolid','Vizcaya','Zamora','Zaragoza','Ceuta','Melilla'];
					
    	if (((Math.floor(x/1000))-1)>-1 && ((Math.floor(x/1000))-1)<52)
			{
				document.primero.provincia.value=provincias[(Math.floor(x/1000))-1];
				return provincias[(Math.floor(x/1000))-1];
			}
		else
			{
				document.primero.provincia.value="";
				return "";
			}
}



/*
C1 Se ha introducido un cif correcto.
C2 Se ha introducido un cif erróneo. El carácter de control es
	erróneo.
N1 Se ha introducido un NIF correcto
N2 Se ha introducido un NIF erróneo. El carácter de control es
	erróneo.
N3 Se ha introducido un DNI, se ha pasado un número de entre 6
	y 8 dígitos con un valor mínimo de 100000.
0 Se ha introducido un dato no válido. No es CIF.
*/

function nif_cif()
{
    let Nif= /^[XYZLKM0-9]/;
    let Cif= /^[A-HJUVPQRSW]/;
    let cadena=document.primero.nif_cif.value.toString().toUpperCase();
    if (Nif.test(cadena))
    {
        let V=esNif(cadena);
        if (V==4) return 0;
        else return "N"+V;//retorna N1, N2 o N3 
    }
    else if (Cif.test(cadena))
    {
        let V=esCif(cadena);
        if (V==3) return 0;
        else return "C"+V;//retorna C1 o C2
    }
    else return "0";
}
/*
1 -> Se ha introducido un NIF correcto.
2 -> Se ha introducido un NIF erróneo. El carácter de control es
erróneo.
3 -> Se ha introducido un DNI, se ha pasado un número de entre 6 y
8 dígitos con un valor mínimo de 100000.
4 -> Se ha introducido un dato no válido. No es NIF ni un DNI.
 */
function esNif(cadena)
{
    let letras=["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"];
    //Primera forma Ocho dígitos y el carácter de control que va a ser una letra. 
    let primF = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]{1}$/i;
    //2ª forma En la primera posición una letra que puede ser: X, Y, Z, L, K, M; a
        //continuación siete dígitos y el carácter de control que va a ser una letra.
    let segF = /^[XYZLKM]{1}[0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;
    //un número de entre 6 y 8 dígitos
    let dig = /^[0-9]{6,8}$/i;//dni antiguo solo tiene de 6 a 8 numeros y sin letra de control
    let letra= cadena.substr(-1);
    if (primF.test(cadena))
        if (letras[parseInt(cadena.substr(0, 8))%23]==letra)//verdadero si es nif que empiesa por una letra y es correcto
            return 1;
        else return 2;
    else if (segF.test(cadena))
    {
        //remplaza la letra por el numero correspondiente
        let valorLetra=letraNif(cadena.charAt(0));
        cadena=valorLetra+cadena.substr(1,7);
        /*
       cadena=cadena    .replace(/^[X]/, '0')	
                        .replace(/^[Y]/, '1') 
                        .replace(/^[Z]/, '2') 
                        .replace(/^[L]/, '3') 
                        .replace(/^[K]/, '4') 
                        .replace(/^[M]/, '5');
        */
        if (letras[parseInt(cadena.substr(0, 8))%23]==letra)//verdadero si es nif que empiesa por un numero y es correcto
            return 1;
        else return 2;
    }
    else if (dig.test(cadena))
        if (parseInt(cadena.substr(0, 8))>=100000)//verdadero si es dni y es mayor 100000
            return 3;
    return 4;
}
function letraNif(letraC) {
	let letra="XYZLKM";
	for (let i=0; i < letra.length; i++){
		if (letraC==letra.charAt(i))
		return i;
	}
}
/*
1 -> Se ha introducido un cif correcto.
2 -> Se ha introducido un cif erróneo. El carácter de control es erróneo.
3 -> Se ha introducido un dato no válido. No es CIF.
*/
function esCif(cadena)
{
    // 1 forma -> 1 letra - 7 digitos - un numero de control
    let formato1 = /^[A-HJUV]{1}[0-9]{7}[0-9]$/i;
    // 2 forma -> 1 letra - 7 digitos - una letra de control
    let formato2 = /^[PQRSW]{1}[0-9]{7}[A-J]$/i;
    let letrasC="JABCDEFGHI";
    if (formato1.test(cadena) || formato2.test(cadena))//Obtiene los formatos
    {
        let dig7 = cadena.substr(1,7);
        let suma=0;
        let i;
        let dig;
        for ( i=1; i <= dig7.length; i++){
            dig=dig7.substr((i-1),1);//si empiezo por cero el if coje el primer digito y solo debe cojer los pares
            if (i%2 != 0)//Si es impar entra
            {
                dig*=2;
                if (dig > 9)
                   { 
                       dig=dig.toString();
                       dig=(parseInt)(dig.charAt(0))+(parseInt)(dig.charAt(1));//suma los digitos
                   }
                //alert(dig);
            }
            //suma los par y los impares*2
            suma+=parseInt(dig);
        }
        let resto=suma%10;
        resto=10-resto;
        if (resto==10)
            resto=0;
        let control=cadena.substr(-1);
        if (letrasC.substr(resto,1)==control)
            return 1;//cif correcto por control letra
        else if (resto==control)
            return 1;//cif correcto por control numero
        else return 2;//cif incorrecto por el cararter
    }
    return 3;
}//15232144


/*
Recibe tres parametros
Retorna el numero de codigo de cuenta que son 2 digitos
*/
//Recordar convertir todos los parametros en string
function codigosControl(codigoBanco,sucursal,numeroDecuenta)
{
	//alert(codigoBanco);
    let xCodigoBanco=[4,8,5,10];
    let xSucursal=[9,7,3,6];
    let xNumeroDecuenta=[1,2,4,8,5,10,9,7,3,6];
    let numero1=0;
    let numero2=0;
    for (let index = 0; index < 4; index++) {
        numero1+=((parseInt)(codigoBanco.charAt(index))*xCodigoBanco[index]);
        numero2+=((parseInt)(sucursal.charAt(index))*xSucursal[index]);
        
    }
    let suma=numero1+numero2;
    let resto=suma%11;    
    let primerDigitoC=11-resto;
    
    if (primerDigitoC>9)
    {
        if (primerDigitoC==10)
            primerDigitoC=1;
        else primerDigitoC=0;//en caso de que sea 11 porque en teoria no deberia salir un numero mayor
    }
    let numero3=0;
    for (let index = 0; index < 10; index++) {
        numero3+=((parseInt)(numeroDecuenta.charAt(index))*xNumeroDecuenta[index]);   
    }
    resto=numero3%11;
    let segundoDigitoC=11-resto;
    if (segundoDigitoC>9)
    {
        if (segundoDigitoC==10)
            segundoDigitoC=1;
        else segundoDigitoC=0;//en caso de que sea 11 porque en teoria no deberia salir un numero mayor
    }
    let controlF=primerDigitoC+""+segundoDigitoC;
    return controlF;
}

function calculoIBANEspanya(cuenta)//Tiene que validarse cuanta cuando se llame a la funcion
{
    let espanya="ES00"
    let IBAN=cuenta+espanya;
    IBAN=IBAN   .replace(/E/,14)
                .replace (/S/,28);
    let resto=((parseInt)(IBAN))%11;
    let C=98-resto;
    if (C<10)
        IBAN="ES0"+C.toString+cuenta;
    else IBAN="ES"+C.toString+cuenta;
    return IBAN;
}

function comprobarIBAN(IBAN)
{
	let Cdigitos=IBAN.substr(0,4);
   let letra1=Cdigitos.charAt(0);
   let letra2=Cdigitos.charAt(1);
 
   if (lengthPais(letra1+letra2)==IBAN.length)
   {
	   //Remplasamos las letras por sus numeros correspondientes
	   let numero1=letraIBAN(letra1);
	   let numero2=letraIBAN(letra2);
	   //Ponemos los primeros cuatro digitos al final
	   let ibanAux=IBAN.substr(4)+numero1+numero2+Cdigitos.charAt(2)+Cdigitos.charAt(3);
	   if (porcentaje97(ibanAux)==1)//if (((parseInt)(ibanAux))%97==1)
	   	return true;
	   return false;
   }
   return false;
}
function letraIBAN(letraIBAN) {
	letra="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for (let index = 0; index < letra.length; index++) {
		if (letraIBAN==charAt(index))
		return index+10;
	}
}
function lengthPais(cPais) {
	let posicion=["DE","BE","CY","DK","SI","EE","FR","HU","IT","LT","MT","PL","GB","RO","IS","CH","MC","AT","BG","HR","SK","ES","FI","GR","IE","LV","LU","NL","PT","CZ","SE","NO","SM","LI"];
	let Ncarateres=[22,16,28,18,19,20,27,28,27,20,31,28,22,24,26,21,27,20,22,21,24,24,18,27,22,21,20,18,25,24,24,15,27,21];
	let resultado=posicion.indexOf(cPais);	
	if (resultado!=-1)
	return Ncarateres[resultado];
	else return resultado;
}
function porcentaje97(valor) 
{
	while(valor.length>16)//9007199254740991 este es el numero maximo que soporta Int
	{
		let auxValor=((parseInt)(valor.substr(0,9)))%97;
		valor=auxValor+valor.substr(9);
	}
	return ((parseInt)(valor)%97);
}






