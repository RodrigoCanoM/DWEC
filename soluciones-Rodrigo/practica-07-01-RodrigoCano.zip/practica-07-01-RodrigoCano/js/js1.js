let peticion_http;
if (document.addEventListener)
window.addEventListener("load",inicio)
else if (document.attachEvent)
window.attachEvent("onload",inicio);

function inicio(){
}

function cambio(enlace){
    if(window.XMLHttpRequest){
        peticion_http=new XMLHttpRequest();
    }else if(window.ActiveXObject){
        peticion_http=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(document.addEventListener)
        peticion_http.addEventListener("readystatechange", contenido);
    else if(document.attachEvent)
        peticion_http.attachEvent("onreadystatechange",contenido);
    peticion_http.open('GET',enlace,true);
    peticion_http.send(null);
    
}

function contenido(){
    if(peticion_http.readyState==4){
        if(peticion_http.status==200){
            let ele_div=document.getElementById("contenido");
            ele_div.innerHTML=peticion_http.responseText;
        }
    }
}