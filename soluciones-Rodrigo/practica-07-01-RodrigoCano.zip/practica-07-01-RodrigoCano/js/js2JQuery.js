$(function(){
    cambio("txt/cantabria.txt");
})
function cambio(enlace){
    $("#contenido").load("http://127.0.0.1/js/practica-07-01-RodrigoCano/"+ enlace);
}

