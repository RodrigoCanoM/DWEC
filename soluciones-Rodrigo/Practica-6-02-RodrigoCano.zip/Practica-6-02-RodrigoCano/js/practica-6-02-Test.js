if (document.addEventListener)
	window.addEventListener("load",inicio)
else if (document.attachEvent)
	window.attachEvent("onload",inicio);

function inicio(){

    let enviars=document.getElementById("enviar");
    let apellido=document.formulario.apellidos;
    let nombre=document.formulario.nombre;
    let via=document.formulario.tVia;
    let nomvia=document.formulario.nVia;
    let numero=document.formulario.numero;
    let portal=document.formulario.portal;
    let piso=document.formulario.piso;
    let puerta=document.formulario.puerta;
    let localidad=document.formulario.localidad;
    let provincia=document.formulario.provincia;
    let pais=document.formulario.pais;
    let trabajo=document.formulario.trabajo;
    let empresa=document.formulario.nEmpresa;
    let categoria=document.formulario.categoria;
    
    mensaje();

    if (document.addEventListener){
        //enviar.addEventListener("click",comprobar);
        apellido.addEventListener("change",Apellidos);
        nombre.addEventListener("change",Nombre);
        via.addEventListener("change",Via);
        nomvia.addEventListener("change",NombreVia);
        numero.addEventListener("change",Numero);
        portal.addEventListener("change",Portal);
        piso.addEventListener("change",Piso);
        puerta.addEventListener("change",Puerta);
        localidad.addEventListener("change",Localidad);
        provincia.addEventListener("change",Provincia);
        pais.addEventListener("change",Pais);
        trabajo.addEventListener("change",Trabajo);
        empresa.addEventListener("change",Empresa);
        categoria.addEventListener("change",Profesional);
        enviars.addEventListener("click",aficiones);
    }else if(document.attachEvent){
        //enviar.attachEvent("onclick",comprobar);
        nvia.attachEvent("onchange",Apellidos);
        nombre.attachEvent("onchange",Nombre);
        via.attachEvent("onchange",Via);
        nomvia.attachEvent("onchange",NombreVia);
        numero.attachEvent("onchange",Numero);
        portal.attachEvent("onchange",Portal);
        piso.attachEvent("onchange",Piso);
        puerta.attachEvent("onchange",Puerta);
        localidad.attachEvent("onchange",Localidad);
        provincia.attachEvent("onchange",Provincia);
        pais.attachEvent("onchange",Pais);
        trabajo.attachEvent("onchange",Trabajo);
        empresa.attachEvent("onchange",Empresa);
        categoria.attachEvent("onchange",Profesional);
        enviars.attachEvent("onclick",aficiones);
    }
}
  
 var letras="áéíóúüñ";
 var adicionales=new Array("ª","º","-"," ");
 var adiEsp= new Array(" ");


//Funcion appellidos
function Apellidos(){
    let apellido=document.formulario.apellidos.value.trim().toLowerCase();
    let erap=document.getElementById("erap");//ErrorApellido
    let comp=/^[a-z][a-z -]{5,+}[a-z]$/;
    erap.textContent="";
    //Comprobar Apellido
    if(!comp.test(apellido)){
        erap.textContent="Obligatorio, empieza y termina por letra, min. 7 caract";
    }
}


//Función comprobar nombre
function Nombre(){
    let nombre=document.formulario.nombre.value.trim().toLowerCase();
    let ernom=document.getElementById("ernom");
    let comp=/^[a-z][a-zºª. -]{1,28}[a-z]$/;
    ernom.textContent="";
    //Comprobar Nombre
    if(!comp.test(nombre)){
       ernom.textContent="Obligatorio, empieza y termina por letra, min. 3 caract , max. 30 caract";
   }
}


//Función tipo via
function Via(){
    //Comprobar tipo de vía
    let tipoV=document.getElementById("tVia").value.toLowerCase();
    let ertvia=document.getElementById("ertvia");
    let comp=/^((calle)|(plaza)|(camino)|(avenida)|(plazuela)|(bulevar)|(carretera)|(paseo)|(travesía))$/;
    ertvia.textContent="";  	 
  	 if (!comp.test(tipoV)){
        ertvia.textContent="T. vía vacío,(Calle, Plaza, Camino, Avenida, Plazuela, Bulevar, Carretera, Paseo, Travesía)";
    }
}


//Función comprobar nombre de via
function NombreVia(){
    let nomVia=document.getElementById("nVia").value.toLowerCase();
    let ernvia=document.getElementById("ernvia");
    ernvia.textContent="";
    let comp=/^[a-z][a-z ]{1,33}[a-z]$/;
    if (!comp.test(nomVia) ){
        ernvia.textContent="Obligatorio, empieza y termina con letras, min 3 y max 35 caracteres"; 
    }
}


//Función numero
function Numero(){
    //Comprobar número
    let errnum=document.getElementById("ernum");
    let numero=document.getElementById("numero").value.toLowerCase();
    let comp=/^([]|(s\/n)|(\d)+)$/;
    errnum.textContent="";
    if(!comp.test(numero)){
        errnum.textContent="Número puede estar vacío, contener dígitos o 's/n' "; 
    }
}
   
        
//Función portal
function Portal(){
    //Comprobar portal
    let errportal=document.getElementById("erportal");
    let portal=document.getElementById("portal").value.toLowerCase();
    let comp=/^([]|[a-z0-9]+)$/;
    errportal.textContent="";
	 if(!comp.test(portal)){           
	         errportal.textContent="Puede estar vacio o contener caracteres alfanumericos";
	 }
}    


//Funcion piso
function Piso(){
    //Comprobar piso o planta
    let errpiso=document.getElementById("erpiso");
    let piso=document.getElementById("piso").value.trim().toLowerCase();
    let comp=/^([]|[\d]+)$/;
    errpiso.textContent="";
    if(!comp.test(piso)){
        errpiso.textContent="Piso puede estar vacío o contener dígitos";
    }
}

 
//Función puerta
function Puerta(){
    //Comprobar puerta
    let errpuerta=document.getElementById("erpuerta");
    let puerta=document.getElementById("puerta").value.toLowerCase();
    let comp=/^([]|[\d]|[a-z])$/;
    errpuerta.textContent="";
    if(!comp.test(puerta)){
          errpuerta.textContent="Solo puede  contener letras y dígitos o estar vacía";
    }
}


//función localidad
function Localidad(){
    //Comprobar Localidad
    let errLocalidad=document.getElementById("erlocalidad");
    let localidad=document.getElementById("localidad").value.toLowerCase();
    errLocalidad.textContent="";
    let comp=/^[a-z][a-z ]{1,38}[a-z]$/;
    if(!comp.test(localidad)){
        errLocalidad.textContent="Campo Obligatorio, empieza y termina por letra, min 3 y max 40 caracteres";
    }
}

    
//Función provincia
function Provincia(){
    //-//Comprobar Provincia
    let errprovincia=document.getElementById("erprovincia");
    let provincia=document.getElementById("provincia").value.toLowerCase();
    errprovincia.textContent="";
    let comp=/^[a-z][a-z ]{4,30}[a-z]$/;
    if(!comp.test(provincia)){
        errprovincia.textContent="Campo Obligatorio, empieza y termina con letra, min 8 y max 28 caracteres";
    }
}
//Función pais
function Pais(){
    //Comprobar País
    let errpais=document.getElementById("erpais");
    let pais=document.getElementById("pais").value.toLowerCase();
    errpais.textContent="";
    let comp=/^[a-z][a-z ]{6,26}[a-z]$/;
    if(!comp.test(pais)){
        errpais.textContent="Campo Obligatorio, empieza y termina con letra, min 8 y max 28 caracteres";
    }
}

     
//Función trabajo
function Trabajo(){
    //Comprobar Puesto de trabajo
    let errtrbajo=document.getElementById("ertrabajo")
    let pTrabajo=document.getElementById("trabajo").value.toLowerCase();
    errtrbajo.textContent="";
    let comp=/^[a-z][a-z -\d]{8,23}[a-z]$/;
    if(!comp.test(pTrabajo)){
        errtrbajo.textContent="Obligatorio, min 10 y max 25 caracteres, debe empezar y terminar por letra, puede llevar '-' o digitos y espacio";
    }
}
     



//Función empresa
function Empresa(){
    //Comprobar el nombre de la empresa
    let errempresa=document.getElementById("erempresa");
    let nEmpresa=document.getElementById("nEmpresa").value.toLowerCase();
    errempresa.textContent="";
    let comp=/^[a-z][a-z .-\d]{1,23}[a-z]$/;
    if(!comp.test(nEmpresa)){
        errempresa.textContent="Obligatorio, min 10 y max 25 caracteres, debe empezar y terminar por letra, puede llevar '-' o '.' o digitos y espacio";
    }
}



      
//Función profesional
function Profesional(){
    //Comprobar categoría profesional
    let errcategoria=document.getElementById("ercategoria");
    let categoria=document.getElementById("categoria").value.toLowerCase();
    let letr3="abcdefghijklmnopqrstuvwxyz0123456789-. ";
    let comp=/^[a-z][a-z .\d]{6,18}[a-z]$/;
    errcategoria.textContent="";
    if(!comp.test(categoria)){
        errcategoria.textContent="Campo obligatorio, min 8 y max 20 caracteres";
    }
}


function aficiones() {
	let Aficiones = document.querySelectorAll('input[id="aficion"]:checked'); //document.forms[0];
	alert(Aficiones.length);
	//alert(Aficiones[7].value);
	let contenido="";
	for (let indice=0; indice<Aficiones.length; indice++) {
		alert(indice+Aficiones[indice].value);
		if (indice!=0)
			contenido+="-";
		contenido+=Aficiones[indice].value;
		//alert(mensaje);
	}
	document.cookie="aficiones="+contenido+";expires=Thu;01 Jan 2030 00:00:00 UTC; path=/";
	alert(document.cookie);
	return true;
}

function mensaje() {
	let existe=document.cookie.indexOf("aficiones=");
	alert(existe);

}
