if (document.addEventListener)
	window.addEventListener("load",inicio)
else if (document.attachEvent)
	window.attachEvent("onload",inicio);

function inicio(){

    let enviars=document.getElementById("enviar");
    let apellido=document.formulario.apellidos;
    let nombre=document.formulario.nombre;
    let via=document.formulario.tVia;
    let nomvia=document.formulario.nVia;
    let numero=document.formulario.numero;
    let portal=document.formulario.portal;
    let piso=document.formulario.piso;
    let puerta=document.formulario.puerta;
    let localidad=document.formulario.localidad;
    let provincia=document.formulario.provincia;
    let pais=document.formulario.pais;
    let trabajo=document.formulario.trabajo;
    let empresa=document.formulario.nEmpresa;
    let categoria=document.formulario.categoria;
    
    mensaje();

    if (document.addEventListener){
        //enviar.addEventListener("click",comprobar);
        apellido.addEventListener("change",Apellidos);
        nombre.addEventListener("change",Nombre);
        via.addEventListener("change",Via);
        nomvia.addEventListener("change",NombreVia);
        numero.addEventListener("change",Numero);
        portal.addEventListener("change",Portal);
        piso.addEventListener("change",Piso);
        puerta.addEventListener("change",Puerta);
        localidad.addEventListener("change",Localidad);
        provincia.addEventListener("change",Provincia);
        pais.addEventListener("change",Pais);
        trabajo.addEventListener("change",Trabajo);
        empresa.addEventListener("change",Empresa);
        categoria.addEventListener("change",Profesional);
        enviars.addEventListener("click",aficiones);
    }else if(document.attachEvent){
        //enviar.attachEvent("onclick",comprobar);
        nvia.attachEvent("onchange",Apellidos);
        nombre.attachEvent("onchange",Nombre);
        via.attachEvent("onchange",Via);
        nomvia.attachEvent("onchange",NombreVia);
        numero.attachEvent("onchange",Numero);
        portal.attachEvent("onchange",Portal);
        piso.attachEvent("onchange",Piso);
        puerta.attachEvent("onchange",Puerta);
        localidad.attachEvent("onchange",Localidad);
        provincia.attachEvent("onchange",Provincia);
        pais.attachEvent("onchange",Pais);
        trabajo.attachEvent("onchange",Trabajo);
        empresa.attachEvent("onchange",Empresa);
        categoria.attachEvent("onchange",Profesional);
        enviars.attachEvent("onclick",aficiones);
    }
}
  
 var letras="áéíóúüñ";
 var adicionales=new Array("ª","º","-"," ");
 var adiEsp= new Array(" ");


//Funcion appellidos
function Apellidos(){
    let adicionalesAp=new Array("-"," ");
    let apellido=document.formulario.apellidos.value.trim().toLowerCase();
    let erap=document.getElementById("erap");//ErrorApellido
    erap.textContent="";
    if(apellido.length>=7){
        //Empieza por letra
	   if(apellido.charAt(0)<"a" || apellido.charAt(0)>"z"){
	       //alert("No empieza en letra");
	       erap.textContent="Obligatorio, empieza y termina por letra, min. 7 caract";
	   }
        //Termina por letra
      let posicion=apellido.length-1;
      if(apellido.charAt(posicion)<"a" || apellido.charAt(posicion)>"z")
          if(!letras.includes(apellido.charAt(posicion))){
              erap.textContent="Obligatorio, empieza y termina por letra, min. 7 caract";
          }
        //En medio letras, espacio y guión
        for(let i=1; i<posicion; i++){
            if(apellido.charAt(i)<"a" || apellido.charAt(i)>"z")
                if(!letras.includes(apellido.charAt(i)) && !adicionalesAp.includes(apellido.charAt(i)))
							erap.textContent="Obligatorio, empieza y termina por letra, min. 7 caract";
        }        
        
    }else{
        erap.textContent="Obligatorio, empieza y termina por letra, min. 7 caract";
    }
}


//Función comprobar nombre
function Nombre(){
    let adicionalesNom=new Array("ª", "º","."," ");
    let nombre=document.formulario.nombre.value.trim().toLowerCase();
    let ernom=document.getElementById("ernom");
    ernom.textContent="";
    //Comprobar Nombre
    if(nombre.length>=3 && nombre.length<=30){
        //Empieza por letra
        if(nombre.charAt(0)<"a" || nombre.charAt(0)>"z"){
            ernom.textContent="Obligatorio, empieza y termina por letra, max. 30 caract";
        }
       //Nombre termina en letra
       let posicionN=nombre.length-1;
	     if(nombre.charAt(posicionN)<"a" || nombre.charAt(posicionN)>"z"){
	           ernom.textContent="Obligatorio, empieza y termina por letra, max. 30 caract";
	        }
	     for(let i=1; i<posicionN; i++){
	            if(nombre.charAt(i)<"a" || nombre.charAt(i)>"z")
	                if(!letras.includes(nombre.charAt(i)) && !adicionalesNom.includes(nombre.charAt(i)))
								ernom.textContent="Obligatorio, empieza y termina por letra, max. 30 caract";
	     }
   }else{
       ernom.textContent="Obligatorio, min. 3 caract , max. 30 caract";
   }
}


//Función tipo via
function Via(){
    //Comprobar tipo de vía
    let tipoV=document.getElementById("tVia").value.trim().toLowerCase();
    let tipoVias=["calle","plaza","camino","avenida","plazuela","bulevar","carretera","paseo","travesía"];
    let ertvia=document.getElementById("ertvia"); 
    ertvia.textContent="";  	 
  	 if (!tipoVias.includes(tipoV)) {
        ertvia.textContent="T. vía vacío,(Calle, Plaza, Camino, Avenida, Plazuela, Bulevar, Carretera, Paseo, Travesía)";
    }
}


//Función comprobar nombre de via
function NombreVia(){
    let nomVia=document.getElementById("nVia").value.trim().toLowerCase();
    let ernvia=document.getElementById("ernvia");
    ernvia.textContent="";
    if(nomVia.length>=3 && nomVia.length<=35){
         //Empieza por letra
         if(nomVia.charAt(0)<"a" || nomVia.charAt(0)>"z"){
             ernvia.textContent="Obligatorio, empieza y termina por letra, en medio espacios";
         }
        //Termina en letra
        let posNVia=nomVia.length-1;
	      if(nomVia.charAt(posNVia)<"a" || nomVia.charAt(posNVia)>"z"){
              ernvia.textContent="Obligatorio, empieza y termina por letra, en medio espacios";
         }
	      for(let i=1; i<posNVia; i++){
	            if(nomVia.charAt(i)<"a" || nomVia.charAt(i)>"z")
	                if(!adiEsp.includes(nomVia.charAt(i)))
								ernvia.textContent="Obligatorio, empieza y termina por letra, en medio espacios";
	     	}
    }else{
        ernvia.textContent="Obligatorio, min 3 y max 35 caracteres"; 
    }
}


//Función numero
function Numero(){
    //Comprobar número
    let errnum=document.getElementById("ernum");
    let numero=document.getElementById("numero").value.trim().toLowerCase();
    errnum.textContent="";
    if(isNaN(numero) && numero!=="" && numero!=="s/n"){
        errnum.textContent="Número puede estar vacío, contener dígitos o 's/n' "; 
    }
}
   
        
//Función portal
function Portal(){
    //Comprobar portal
    let errportal=document.getElementById("erportal");
    let portal=document.getElementById("portal").value.trim().toLowerCase();
    let validos="abcdefghijklmnopqrstuvwxyz0123456789";
    errportal.textContent="";
	  for(let j=0; j<=portal.length; j++){               
	     if(!validos.includes(portal.charAt(j)) ){           
	         errportal.textContent="Puede estar vacio o contener caracteres alfanumericos";
	     }
	  }
}    


//Funcion piso
function Piso(){
    //Comprobar piso o planta
    let errpiso=document.getElementById("erpiso");
    let piso=document.getElementById("piso").value.trim().toLowerCase();
    errpiso.textContent="";
    if(isNaN(piso) && piso!==""){
        errpiso.textContent="Piso puede estar vacío o contener dígitos";
    }
}

 
//Función puerta
function Puerta(){
    //Comprobar puerta
    let errpuerta=document.getElementById("erpuerta");
    let puerta=document.getElementById("puerta").value.toLowerCase();
    let validos="abcdefghijklmnopqrstuvwxyz0123456789";
    errpuerta.textContent="";
    for(let l=0; l<=puerta.length; l++){
      if(!validos.includes(puerta.charAt(l)) && puerta.charAt(l)!="") {
          errpuerta.textContent="Solo puede  contener letras y dígitos o estar vacía";
      }
    }
}


//función localidad
function Localidad(){
    //Comprobar Localidad
    let errLocalidad=document.getElementById("erlocalidad");
    let localidad=document.getElementById("localidad").value.toLowerCase();
    errLocalidad.textContent="";
    if(localidad.length>=3 && localidad.length<=40){
        //Empieza por letra
	      if(localidad.charAt(0)<"a" || localidad.charAt(0)>"z"){
	          errLocalidad.textContent="Empieza y termina por letra, max 40 caracteres";
	      }

         //Termina en letra
         var posLocalidad=localidad.length-1;
         
             if(localidad.charAt(posLocalidad)<"a" || localidad.charAt(posLocalidad)>"z"){
                     errLocalidad.textContent="Empieza y termina por letra, max 40 caracteres";
             }
                 
         for(let i=1;i<posLocalidad;i++){
             if(localidad.charAt(i)<"a" || localidad.charAt(i)>"z")
                 if(!adiEsp.includes(localidad.charAt(i))){
                     errLocalidad.textContent="Empieza y termina por letra, max 40 caracteres";
                 }
         }
    }else{
        errLocalidad.textContent="Campo Obligatorio, min 3 y max 40 caracteres";
    }
}

    
//Función provincia
function Provincia(){
    //-//Comprobar Provincia
    let errprovincia=document.getElementById("erprovincia");
    let provincia=document.getElementById("provincia").value.toLowerCase();
    errprovincia.textContent="";
    if(provincia.length>=6 && provincia.length<=32){
       //Empieza por letra
        if(provincia.charAt(0)<"a" || provincia.charAt(0)>"z"){
            errprovincia.textContent="Obligatorio, empieza y termina por letra, en medio espacios";
        }


       //Termina en letra
       
       let posProvincia=provincia.length-1;
	     if(provincia.charAt(posProvincia)<"a" || provincia.charAt(posProvincia)>"z"){
	             errprovincia.textContent="Obligatorio, empieza y termina por letra, en medio espacios";
	         }
               
       //Puede contener espacios o letras en medio
       for(let l=1; l<posProvincia; l++){
         if(provincia.charAt(l)<"a" || provincia.charAt(l)>"z"){
             if(provincia.charAt(l)!=" ")
             	errprovincia.textContent="Obligatorio, empieza y termina por letra, en medio espacios";
         }
       }
    } else{
        errprovincia.textContent="Campo obligatorio, min 6 y max 32 caracteres";
    }
}


//Función pais
function Pais(){
    //Comprobar País
    let errpais=document.getElementById("erpais");
    let pais=document.getElementById("pais").value.toLowerCase();
    errpais.textContent="";
    if(pais.length>=8 && pais.length<=28){
	     //Empieza por letra
        if(pais.charAt(0)<"a" || pais.charAt(0)>"z"){
            errpais.textContent="Empieza y termina por letra, en medio espacios";
        }
	
	     //Termina en letra 
	     let posPais=pais.length-1;
	      if(pais.charAt(posPais)<"a" || pais.charAt(posPais)>"z"){
	           errpais.textContent="Empieza y termina por letra, en medio espacios";
	       }

	     //Puede contener espacios o letras en medio
	     for(let l=1; l< posPais; l++){
				if(pais.charAt(l)<"a" || pais.charAt(l)>"z")
					if(provincia.charAt(l)!=" ")
	           		errpais.textContent="Empieza y termina por letra, en medio espacios";
	     }

    } else{
        errpais.textContent="Campo Obligatorio, min 8 y max 28 caracteres";
    }
}


     
//Función trabajo
function Trabajo(){
    //Comprobar Puesto de trabajo
    let errtrbajo=document.getElementById("ertrabajo")
    let pTrabajo=document.getElementById("trabajo").value.toLowerCase();
    let letr2="abcdefghijklmnopqrstuvwxyz0123456789- ";
    errtrbajo.textContent="";
    if(pTrabajo.length>=10 && pTrabajo.length<=25){
        //Empieza por letra
          if(pTrabajo.charAt(0)<"a" || pTrabajo.charAt(0)>"z"){
              errtrbajo.textContent="Empieza y termina por letra, en medio espacios";
          }
        //Termina en letra 
    let posTrabajo=pTrabajo.length-1;
    if(pTrabajo.charAt(posTrabajo)<"a" || pTrabajo.charAt(posTrabajo)>"z"){
            errtrbajo.textContent="Empieza y termina por letra, en medio espacios";
        }

      //Puede contener espacios o letras en medio
      for(let l=1; l<=posTrabajo; l++){
         if(!letr2.includes(pTrabajo.charAt(l)))
         	 	errtrbajo.textContent="Empieza y termina por letra, en medio espacios, digitos y '-'";
      }    
    } else{
        errtrbajo.textContent="Campo Obligatorio, min 10 y max 25 caracteres";
    }
}
     



//Función empresa
function Empresa(){
    //Comprobar el nombre de la empresa
    let errempresa=document.getElementById("erempresa");
    let letr3="abcdefghijklmnopqrstuvwxyz0123456789-. ";
    let nEmpresa=document.getElementById("nEmpresa").value.toLowerCase();
    errempresa.textContent="";
    if(nEmpresa.length>=6 && nEmpresa.length<=25){
        //Empieza por letra
        if(nEmpresa.charAt(0)<"a" || nEmpresa.charAt(0)>"z"){
            errempresa.textContent="Empieza y termina por letra";
        }

          //Termina en letra 
       let posEmpresa=nEmpresa.length-1;
        if(nEmpresa.charAt(posEmpresa)<"a" || nEmpresa.charAt(posEmpresa)>"z"){
            errempresa.textContent="Empieza y termina por letra";
        }
          //Puede contener espacios o letras en medio
          for(let l=0; l<=nEmpresa.length; l++){
            if(!letr3.includes(nEmpresa.charAt(l))){
                errempresa.textContent="Empieza y termina por letra, en medio espacio, digitos, puntos o guiones";
            }
          }
    } else{
        errempresa.textContent="Campo obligatorio, min 6 y max 25 caracteres";
    }
}



      
//Función profesional
function Profesional(){
    //Comprobar categoría profesional
    let errcategoria=document.getElementById("ercategoria");
    let categoria=document.getElementById("categoria").value.toLowerCase();
    let letr3="abcdefghijklmnopqrstuvwxyz0123456789-. ";
    errcategoria.textContent="";
    if(categoria.length>=8 && categoria.length<=20){
        //Empieza por letra
         if(categoria.charAt(0)<"a" || categoria.charAt(0)>"z"){
             errcategoria.textContent="Empieza y termina por letra";
         }

        //Termina en letra 
        let posCategoria=categoria.length-1;
	      if(categoria.charAt(posCategoria)<"a" || categoria.charAt(posCategoria)>"z"){
	              errcategoria.textContent="Empieza y termina por letra";
	      }

        //Puede contener espacios,letras, digitos en medio
        for(var l=1; l<=posCategoria; l++){
          if(!letr3.includes(categoria.charAt(l)))
              errcategoria.textContent="Empieza y termina por letra, en medio espacio, digitos, puntos o guiones";
        }
    } else{
        errcategoria.textContent="Campo obligatorio, min 8 y max 20 caracteres";
    }
}

function aficiones() {
	let Aficiones = document.querySelectorAll('input[id="aficion"]:checked'); //document.forms[0];
	alert(Aficiones.length);
	//alert(Aficiones[7].value);
	let contenido="";
	for (let indice=0; indice<Aficiones.length; indice++) {
		alert(indice+Aficiones[indice].value);
		if (indice!=0)
			contenido+="-";
		contenido+=Aficiones[indice].value;
		//alert(mensaje);
	}
	document.cookie="aficiones="+contenido+";expires=Thu;01 Jan 2030 00:00:00 UTC; path=/";
	alert(document.cookie);
	mensaje();
	return true;
}

function mensaje() {
	let existe=document.cookie.indexOf("aficiones=");
	alert(existe);

}


