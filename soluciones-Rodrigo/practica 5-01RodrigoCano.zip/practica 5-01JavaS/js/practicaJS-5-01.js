window.onload=cargado;
function cargado(){
//1.-Fondo rojo cuando el raton pasa por el
   document.primero.nif.onmouseover=colorFondoEnc;
   document.primero.nombre.onmouseover=colorFondoEnc;
   document.primero.apellidos.onmouseover=colorFondoEnc;
   document.primero.domicilio.onmouseover=colorFondoEnc;
   document.primero.localidad.onmouseover=colorFondoEnc;
   document.primero.cp.onmouseover=colorFondoEnc;
   document.primero.provincia.onmouseover=colorFondoEnc;
//2.-Fondo blanco cuando el raton pasa por el
   document.primero.nif.onmouseout=colorFondoNor;
   document.primero.nombre.onmouseout=colorFondoNor;
   document.primero.apellidos.onmouseout=colorFondoNor;
   document.primero.domicilio.onmouseout=colorFondoNor;
   document.primero.localidad.onmouseout=colorFondoNor;
   document.primero.cp.onmouseout=colorFondoNor;
   document.primero.provincia.onmouseout=colorFondoNor;
//3.-cuando hay un cambio en el cp y solo digitos
	 document.primero.cp.onkeypress=solodigitos;
   document.primero.cp.onchange=codigoPostal;
//4.-Cuando se teclee el codigo Ctrl+F3 saltara la funcion imagenFondo
   document.body.onkeyup=imagenFondo;
//5.-Cambio de imagen segun provincia
	document.primero.onclick=cambiar;
//6.-Cambiar imagen de las aficiones
	document.primero.viajar.onclick=tiempoAficiones;
	document.primero.leer.onclick=tiempoAficiones;
	document.primero.musica.onclick=tiempoAficiones;
	document.primero.cine.onclick=tiempoAficiones;
	document.primero.deporte.onclick=tiempoAficiones;
	document.primero.cena.onclick=tiempoAficiones;
//7.-Bienvenido	
	bienvenido();
//8.-Solo letras
	document.primero.nombre.onkeypress=sololetras;
	document.primero.apellidos.onkeypress=sololetras;
	document.primero.localidad.onkeypress=sololetras;
	//sololetras
//9.- Limpiar formulario
	document.primero.onreset=limpiar;
//10.- Enviar y comprobar
	document.primero.onsubmit=enviar;
}
function bienvenido()
{
	alert("BIENVENIDO");
}
function limpiar(evento)
{
	//Para el tiempo de 10 s de cambio de imagen
		clearInterval(tiempoAf);
		contador=0;
	//Limpia las imagenes	
		document.primero.img_aficion.src="noExisto.jpg";
		document.primero.imgprovincia.src="noExisto.jpg";
	//Limpia el formulario
		document.primero.reset();
}

function colorFondoEnc(evento)
{
    var elemento=evento.target;
	elemento.style.background="red";
}
function colorFondoNor(evento)
{
    var elemento=evento.target;
	elemento.style.background='white';
}
function codigoPostal()
{
	var x = document.primero.cp.value;
	var provincias = ['Alava','Albacete','Alicante','Almeria','Avila','Badajoz',					'Islas Baleares','Barcelona','Burgos','Caceres','Cadiz',						'Castellon','Ciudad Real','Cordoba',
					'La Coruña','Cuenca','Gerona','Granada','Gualdajara','Guipúzcoa','Huelva','Huesca','Jaén','León','Lérida','La Rioja','Lugo','Madrid','Málaga','Murcia',
					'Navarra','Orense','Asturias','Palencia','Las Palmas','Pontevedra','Salamanca','Santa Cruz de Tenerife','Cantabria','Segovia','Sevilla','Soria','Tarragona',
					'Teruel','Toledo','Valencia','Valladolid','Vizcaya','Zamora','Zaragoza','Ceuta','Melilla'];
					
    	if (((Math.floor(x/1000))-1)>-1 && ((Math.floor(x/1000))-1)<52)
			document.primero.provincia.value=provincias[(Math.floor(x/1000))-1]
				//document.getElementById("provincia").value=provincias[(Math.floor(x/1000))-1]
		else {
			document.primero.provincia.value="";
			alert("Error: Codigo postal incorrecto");
		}
}
/*
function validar(x)
{
    if (isNaN(x))
    return false
	else return true;
}*/
function solodigitos(evento){
 var valido=true;
 var valor=String.fromCharCode(evento.charCode);
 if(valor <"0"|| valor >"9")
 valido=false;
 return valido;
 }

var numero=0;//Contador imagen
function imagenFondo(evento)//Ctrl + F3
{
    if (evento.ctrlKey && evento.keyCode==114)
    {
    	var imagenes=["url('imagenes/Paris Torre Eiffel.jpg')",
    	"url('imagenes/Venecia Plaza San Marcos.jpg')",
    	"url('imagenes/lisboa torre belem.jpg')",
    	"url('imagenes/atena acropoli.jpg')",
    	"url('imagenes/roma fontana di trevi.jpg')"];
    	document.body.style.backgroundImage=imagenes[numero++];
    	if (numero==5)
    	numero=0;
    }
}


function cambiar()
{
	//X= usa el valor
	/*cordoba
	leon
	segovia
	sevilla*/
	var x= document.primero.provin.value;
	document.primero.imgprovincia.src="imagenes/"+x+".jpg";
}
var contador=0;//Contador de la primera vez de tener una aficcion
var tiempoAf;
function tiempoAficiones() {
	//https://www.w3schools.com/jsref/met_win_clearinterval.asp
	if (contador==0)
	{
		tiempoAf = setInterval(aficcion, 10000);
		contador++;
	}
}

var ultimo=11;

function aficcion()
{
	var y = document.forms[0];
	var i;
	if(ultimo!=18)
	i=ultimo+1;
	else i=11;
	var confirmar=false;
	do {
		if (y[i].checked==true)
		{
			confirmar=true;
			ultimo=i;
		}
		else if(i==18)
			i=13;
		else i++;
	} while (confirmar==false || i!=ultimo/*hacer una vuelta*/ );
			if (y[ultimo].checked)
			{
				if(y[ultimo].value=="cena")//El nombre del img es diferente del valor
				document.primero.img_aficion.src="imagenes/cenar.jpg";
				else
				document.primero.img_aficion.src="imagenes/"+y[ultimo].value+".jpg";
			}
			
}

function sololetras(evento) {
	var valido=true;
	var otros=new Array("ñ","á","é","í","ó","ú","ü"," ");//Ñ vocales acentuiadas, espacio y u con dieresis
	var valor=String.fromCharCode(evento.charCode).toLowerCase();
	if(valor <"a"|| valor >"z")//letras alfabeto inglés
	if(evento.keyCode!=8&&!otros.includes(valor))//tecla retroceso y letras españolas
	valido=false;
	return valido;
}
function enviar() {
	var enviar=true;
	//a - No funciona
	
	if (enviar)
	{
		var letras=["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"];
		
		var niMayus=document.primero.nif.value.toString().toUpperCase();
		alert(niMayus);
		//https://www.w3schools.com/jsref/jsref_regexp_ncaret.asp
		//https://www.w3schools.com/jsref/jsref_regexp_ndollar.asp
		
		var forNif = /^[0-9]{6,8}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;//Comprueba 6-8 primeros digitos comprendidos desde 0-9 y una letra en el ultimo espacio
		var forNie = /^[XYZLKM]{1}[0-9]{5}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i; //Comprueba en el primer espacio la letra XYZ, 5-7 digitos del 0-9, 1 letra al ultimo
		if (!forNif.test(niMayus) && !forNie.test(niMayus)) enviar=false;
		//https://www.designcise.com/web/tutorial/how-to-replace-all-occurrences-of-a-word-in-a-javascript-string
		//X, Y, Z, L, K, M
		
		var x=niMayus .replace(/^[X]/, '0')	.replace(/^[Y]/, '1') .replace(/^[Z]/, '2') .replace(/^[L]/, '3') .replace(/^[K]/, '4') .replace(/^[M]/, '5');
		var letra= niMayus.substr(-1);
		var numero=parseInt(nie.substr(0, 8));
		if (numero<100000) enviar= false;
		var resto=numero%23;
		if (letras[resto]!=letra) enviar= false;
		if (!enviar) alert("Nif incorrecto");;
		
	}
	//b
	/*
	El nombre va a empezar por tres letras, en medio puede tener letras
y espacios y va a terminar por dos letras, su longitud va a estar
comprendida entre 3 y 20 caracteres.
	*/
	/* No funciona
	if (enviar)
	{
		var formato= /^[A-Z,"ñ","á","é","í","ó","ú","ü"]{3} /[A-Z,"ñ","á","é","í","ó","ú","ü"," "]/g];
	}
	*/
	//return enviar;
}



//b
	/*
	El nombre va a empezar por tres letras, en medio puede tener letras
y espacios y va a terminar por dos letras, su longitud va a estar
comprendida entre 3 y 20 caracteres.
	*/
	/*
function nombre(nombre) {
	
	}
*/
