$(function(){

    //let enviars=document.getElementById("enviar");
	$("#enviar").click(aficiones);
    $("#apellidos").change(Apellidos);
    $("#nombre").change(Nombre);
    $("#tVia").change(Via);
    $("#nVia").change(NombreVia);
    $("#numero").change(Numero);
    $("#portal").change(Portal);
    $("#piso").change(Piso);
    $("#puerta").change(Puerta);
    $("#localidad").change(Localidad);
    $("#provincia").change(Provincia);
    $("#pais").change(Pais);
    $("#trabajo").change(Trabajo);
    $("#nEmpresa").change(Empresa);
    $("#categoria").change(Profesional);
    
    //mensaje();
        //enviar.addEventListener("click",comprobar);
        //enviar.attachEvent("onclick",comprobar);
});
 
//Funcion appellidos
function Apellidos(){
    let apellido=$("#apellidos").val().trim();
    let erap=$("#erap");//ErrorApellido
    let comp=/^[a-z][a-z -]{5,+}[a-z]$/i;
    erap.text("");
    //Comprobar Apellido
    if(!comp.test(apellido)){
        erap.text("Obligatorio, empieza y termina por letra, min. 7 caract");
    }
}


//Función comprobar nombre
function Nombre(){
    let nombre=$("#nombre").val().trim();
    let ernom=$("#ernom");
    let comp=/^[a-z][a-zºª. -]{1,28}[a-z]$/i;
    ernom.text("");
    //Comprobar Nombre
    if(!comp.test(nombre)){
       ernom.text("Obligatorio, empieza y termina por letra, min. 3 caract , max. 30 caract");
    }
}


//Función tipo via
function Via(){
    //Comprobar tipo de vía
    let tipoV=$("#tVia").val().trim();
    let ertvia=$("#ertvia");
    let comp=/^((calle)|(plaza)|(camino)|(avenida)|(plazuela)|(bulevar)|(carretera)|(paseo)|(travesía))$/i;
    ertvia.text("");  	 
  	 if (!comp.test(tipoV)){
        ertvia.text("T. vía vacío,(Calle, Plaza, Camino, Avenida, Plazuela, Bulevar, Carretera, Paseo, Travesía)");
    }
}


//Función comprobar nombre de via
function NombreVia(){
    let nomVia=$("#nVia").val().trim();
    let ernvia=$("#ernvia");
    ernvia.text("");
    let comp=/^[a-z][a-z ]{1,33}[a-z]$/i;
    if (!comp.test(nomVia) ){
        ernvia.text("Obligatorio, empieza y termina con letras, min 3 y max 35 caracteres"); 
    }
}


//Función numero
function Numero(){
    //Comprobar número
    let errnum=$("#ernum");
    let numero=$("#numero").val().trim();
    let comp=/^([]|(s\/n)|(\d)+)$/i;
    errnum.text("");
    if(!comp.test(numero)){
        errnum.text("Número puede estar vacío, contener dígitos o 's/n' "); 
    }
}
   
        
//Función portal
function Portal(){
    //Comprobar portal
    let errportal=$("#erportal");
    let portal=$("#portal").val().trim();
    let comp=/^([]|[a-z0-9]+)$/i;
    errportal.text("");
	 if(!comp.test(portal)){           
	         errportal.text("Puede estar vacio o contener caracteres alfanumericos");
	 }
}    


//Funcion piso
function Piso(){
    //Comprobar piso o planta
    let errpiso=$("#erpiso");
    let piso=$("#piso").val().trim();
    let comp=/^([]|[\d]+)$/i;
    errpiso.text("");
    if(!comp.test(piso)){
        errpiso.text("Piso puede estar vacío o contener dígitos");
    }
}

 
//Función puerta
function Puerta(){
    //Comprobar puerta
    let errpuerta=$("#erpuerta");
    let puerta=$("#puerta").val().trim();
    let comp=/^([]|[\d]|[a-z])$/i;
    errpuerta.text("");
    if(!comp.test(puerta)){
          errpuerta.text("Solo puede  contener letras y dígitos o estar vacía");
    }
}


//función localidad
function Localidad(){
    //Comprobar Localidad
    let errLocalidad=$("#erlocalidad");
    let localidad=$("#localidad").val().trim();
    errLocalidad.text("");
    let comp=/^[a-z][a-z ]{1,38}[a-z]$/i;
    if(!comp.test(localidad)){
        errLocalidad.text("Campo Obligatorio, empieza y termina por letra, min 3 y max 40 caracteres");
    }
}

    
//Función provincia
function Provincia(){
    //-//Comprobar Provincia
    let errprovincia=$("#erprovincia");
    let provincia=$("#provincia").val().trim();
    errprovincia.text("");
    let comp=/^[a-z][a-z ]{4,30}[a-z]$/i;
    if(!comp.test(provincia)){
        errprovincia.text("Campo Obligatorio, empieza y termina con letra, min 8 y max 28 caracteres");
    }
}
//Función pais
function Pais(){
    //Comprobar País
    alert("dssd")
    let errpais=$("#erpais");
    let pais=$("#pais").val().trim();
    errpais.text("");
    let comp=/^[a-z][a-z ]{6,26}[a-z]$/i;
    if(!comp.test(pais)){
        errpais.text("Campo Obligatorio, empieza y termina con letra, min 8 y max 28 caracteres");
    }
}
     
//Función trabajo
function Trabajo(){
    //Comprobar Puesto de trabajo
    let errtrbajo=$("#ertrabajo")
    let pTrabajo=$("#trabajo").val().trim();
    errtrbajo.text("");
    let comp=/^[a-z][a-z -\d]{8,23}[a-z]$/i;
    if(!comp.test(pTrabajo)){
        errtrbajo.text("Obligatorio, min 10 y max 25 caracteres, debe empezar y terminar por letra, puede llevar '-' o digitos y espacio");
    }
}
     



//Función empresa
function Empresa(){
    //Comprobar el nombre de la empresa
    let errempresa=$("#erempresa");
    let nEmpresa=$("#nEmpresa").val().trim();
    errempresa.text("");
    let comp=/^[a-z][a-z .-\d]{1,23}[a-z]$/i;
    if(!comp.test(nEmpresa)){
        errempresa.text("Obligatorio, min 10 y max 25 caracteres, debe empezar y terminar por letra, puede llevar '-' o '.' o digitos y espacio");
    }
}



      
//Función profesional
function Profesional(){
    //Comprobar categoría profesional
    let errcategoria=$("#ercategoria");
    let categoria=$("#categoria").val().trim();
    let comp=/^[a-z][a-z .\d]{6,18}[a-z]$/i;
    errcategoria.text("");
    if(!comp.test(categoria)){
        errcategoria.text("Campo obligatorio, min 8 y max 20 caracteres");
    }
}


function aficiones() {
	let Aficiones = $('input[id="aficion"]:checked').val(); //document.forms[0];
	alert(Aficiones);
	//alert(Aficiones[7].value);
	let contenido="";
	for (let indice=0; indice<Aficiones.length; indice++) {
		alert(indice+Aficiones[indice]);
		if (indice!=0)
			contenido+="-";
		contenido+=Aficiones[indice];
		//alert(mensaje);
	}
	document.cookie="aficiones="+contenido+";expires=Thu;01 Jan 2030 00:00:00 UTC; path=/";
	//alert(document.cookie);
	mensaje();
	return true;
}


function mensaje() {
	let existe=document.cookie.indexOf("aficiones=");
	//alert(existe);

}
