$(function(){
      //Registrarse
    $("#registrase").click(mostrarReg);;
    $("#cancelarReg").click(ocultarReg);    
  	 $("#aceptarReg").click(aceptarReg);
        
    //Entrar

    $("#entrar").click(mostrarEnt);;
    $("#cancelarEnt").click(ocultarEnt);    
  	 $("#aceptarEnt").click(aceptarEnt);

    //Terminos
    $("#addDefiniciones").click(addDefinicion);
    
    //Localidades
    $("#addLocalidades").click(addLocalidad);
    
    //Coches
	 $("#addCoches").click(addCoche);
    //changeProvincia
    
    //Cambia Comunidad
    $("#comunidades").change(changeProvincia);
    
    //Mensaje addMensaje
    $("#addMensaje").click(MostrarAddMensaje);;
    $("#cancelarMen").click(OcultarAddMensaje);    
  	 $("#aceptarMen").click(addMensaje);
  
});

function mostrarReg()
{
	ocultarEnt();
	OcultarAddMensaje();
	$("#vRegistrase").slideDown();
	
}
function ocultarReg()
{
	$("#vRegistrase").slideUp();
}
var cerrarS="Cerrar Sesion";
var entrarS="Entrar";
var usuario="Usuario";
function mostrarEnt()
{
    let valor=$("#entrar").val();
    if (valor==entrarS)
    {
    	  ocultarReg();
    	  OcultarAddMensaje();
        $("#vEntrar").slideDown();
    }
    else 
    {
        $("#entrar").val(entrarS);
        $("#usuario").text(entrarS);
        botonMensaje=false;
    }
}
function ocultarEnt()
{
    $("#vEntrar").slideUp();
}
function aceptarReg()
{
    let mensaje="";
    let Cnombre=/^[A-Z]{3}[A-Z0-9]{5,9}$/i;
    let Ccontrasenya=/^[A-Z]{2}[A-Z\d_]{5,11}[A-Z\d]$/i;
    let nombre=$("#nombreReg").val();
    let pass=$("#passReg").val();
    if (!Cnombre.test(nombre))
    	mensaje+="Error en nombre \n";
    if(!Ccontrasenya.test(pass))
    	mensaje+="Error en contraseña \n";
    if (mensaje.length>0)
    {
      alert(mensaje);
      return false;
    }
    else
    {
        ocultarReg();
        let x=nombre+"="+pass+";expires=Thu;01 Jan 2030 00:00:00 UTC; path=/";
     	  document.cookie=x;        
    }
}
var botonMensaje=false;

function aceptarEnt() {
    let nombre=$("#nombreEnt").val();
    //alert(nombre);
    let pass=$("#passEnt").val();
    //alert(pass);
    let cadena=document.cookie;
    //alert(cadena);
    //alert(nombre+":"+pass)
    let posicion=cadena.indexOf(nombre+"="+pass);
    if (posicion==-1)
    {
        alert("Error, el usuario no existe")
        return false;	
    }
    else {
		  $("#usuario").text(usuario+": "+nombre);
        let pass=$("#entrar").val(cerrarS);
        botonMensaje=true;
        ocultarEnt();
    }
}
function MostrarAddMensaje(){
    if (botonMensaje)
    {
    	  ocultarEnt();
        ocultarReg();
        $("#vMensaje").slideDown();
    }
}
function OcultarAddMensaje(){
    $("#vMensaje").slideUp();
}

function addDefinicion(){
    let palabra=$("#palabra").val();
    let concepto=$("#concepto").val();
    if (palabra.length>0 && concepto.length>0)
    {
        let lis=$("#definiciones");
        
        let posicion=buscar(palabra);
        if (posicion==-1)
        {
        	//Crea el termino
        		let nuevoLi=$("<li></li>").text(palabra);
			//Se crea la definicion
        		let nuevoLiDef=$("<li></li>").text(concepto);
        	//Se mete la nueva definicion dentro de una lista ordenada
        		let nuevoOl=$("<ol></ol>").append(nuevoLiDef);
        	//Se mete la lista ordenada al termino
        		nuevoLi.append(nuevoOl);
        	//Se mete el termino a la lista
        		lis.append(nuevoLi);
        }
        else {
        		//Obtenemos los li dentro de #definiciones
        		let el=$("#definiciones>li");
        		//Creamos un li con el concepto
        		let nuevoLiDef=$("<li></li>").text(concepto);
        		//Buscamos el li que tiene el mismo termino con la posicion obtenida
        		let li=el.eq(posicion);
        		//Introducimos el nuevo concepto dentro del li
        		li.find("ol").append(nuevoLiDef);
        }
    }
    else alert("Error: Palabra o concepto vacio")
}
function buscar(palabra)
{
	//Buscamos la palabra y retomamos su posicion, en caso contrario -1
	let el=$("#definiciones>li");
   for (let indice=0; indice < el.length ; indice++ )
   {
   	if (el.eq(indice).contents().eq(0).text()==palabra)
   		return indice;
   }
	return -1;
}
function addLocalidad() 
{
	let lis=$("#localidades");
	let newLocalidad=$("#localidad").val();
	if(newLocalidad.length>0)
	{
		nuevoLi=$("<li></li>").text(newLocalidad);	
		let posicion=posicionLocalidad(newLocalidad);
		if (posicion!=-1)
			lis.contents().eq(posicion).before(nuevoLi);
	}
	else alert("Error: Localidad vacia");
}
function posicionLocalidad(newLocalidad) {
    let el=$("#localidades>li");
    num=0;
	for (let indice=0; indice < el.length ; indice++ )
   {
   	if (el.eq(indice).text()==newLocalidad)
   		return -1;
       if (el.eq(indice).text()>newLocalidad)
       {
         num=indice+1;
       }
       
   }
	return num;
}

function addCoche() 
{
	let trs=$("#coches>tbody");
	let marca=$("#marca").val();
	let modelo=$("#modelo").val();
	let precio=$("#precio").val();
	let testPrecio=/^[0-9]+$/i;
	if (marca.length>0 && modelo.length>0 && testPrecio.test(precio))
	{
		let posicion=posicionCoche(marca,modelo);
		if (posicion!=-1)
		{
			let nuevoTr=$("<tr></tr>");
			nuevoTr.append($("<td></td>").text(marca));
			nuevoTr.append($("<td></td>").text(modelo));
			nuevoTr.append($("<td></td>").text(precio));
			
			trs.contents().eq(posicion).before(nuevoTr);
			
		}
	}
	else 
	{
		let mensaje="";
		if (!testPrecio.test(precio))
			mensaje+="Error: El precio no es un número \n";
		if (marca.length==0 || modelo.length==0)
			mensaje+="Error: La marca o el modelo esta vacio \n";
		alert(mensaje);
	}
}
function posicionCoche(marca,modelo) {
	let tr=$("#coches>tbody").children("tr");
	let num=tr.length;
	let ultimo="";
	let contador=0;
	for (let indice=0; indice < tr.length ; indice++ )
   {

   	let tds=tr.children("td");
   	if (tds.eq(0).text()==marca && tds.eq(1).text()==modelo)
   			return -1;
   }
	for (let indice=0; indice < tr.length ; indice++ )
   {
   	let tds=tr.eq(indice).contents();
   	
   	if (tds.eq(0).text()>=marca)
   	{//Tengo que separar
   			if (contador==0)
   			{
					contador++;
					ultimo=tds.eq(0).text();
				}
				if(ultimo<tds.eq(0).text() || marca<tds.eq(0).text() )
				{
					return indice;				
				}
				if (ultimo>=tds.eq(0).text()) {
					num=indice+1;
   				ultimo=tds.eq(0).text();
   				
   				if(tds.eq(1).text()>modelo)
   				{
						return indice; 			
   				}
   			}	
   	}	
   }
	return num;
}

var oldProv="";

function changeProvincia(){
    let comunidad=$("#comunidades").val();
    if (comunidad!=oldProv)
    {
        oldProv=comunidad;
        drobProvincias();
        addProvicias(comunidad);
        
        $("#comentarioProv").text(comentario(comunidad));
    }
}

function drobProvincias(){
    
    let select=$("select#provincia");
    let ops=select.children("option");
    
	for (let indice=0;indice < ops.length;indice++)
        ops.eq(indice).remove();
}
function addProvicias(comunidad)
{
    let select=$("select#provincia");
    let provincias=provicias(comunidad);
    for (let indice=0; indice < provincias.length ; indice++ )
    {
        let option=$("<option></option>").text(provincias[indice]);
        select.append(option);
    }
}
function provicias(comunidad){
    let provincias=new Array();
    provincias["Andaluci­a"]=["Almería", "Cádiz", "Córdoba", "Granada", "Huelva", "Jaén", "Málaga", "Sevilla",];//
    provincias["Aragon"]=["Huesca", "Teruel", "Zaragoza"];//
    provincias["Asturias"]=["Oviedo"];//
    provincias["Baleares"]=["Palma de Mallorca"];//
    provincias["Pai­s Vasco"]=["Bilbao","San Sebastián","Vitoriaa"];//
    provincias["Canarias"]=["Santa Cruz de Tenerife","Las Palmas de Gran Canaria"];//
    provincias["Cantabria"]=["Santander"];//
    provincias["Castilla-La Mancha"]=["Albacete","Ciudad Real", "Cuenca","Guadalajara","Toledo"];//
    provincias["Castilla y Leon"]=["Ávila", "Burgos", "León", "Salamanca", "Segovia", "Soria", "Valladolid", "Zamora"];//
    provincias["Cataluña"]=["Barcelona", "Gerona", "Lérida", "Tarragona"];//
    provincias["Extremadura"]=["Badajoz","Cáceres"];//
    provincias["Galicia"]=["La Coruña", "Lugo", "Orense", "Pontevedra"];//
    provincias["Madrid"]=["Madrid"];//
    provincias["Murcia"]=["Murcia"];//
    provincias["Navarra"]=["Pamplona"];//
    provincias["La Rioja"]=["Logroño"];//
    provincias["Valencia"]=["Alicante","Castellón de la Plana", "Valencia"];//
    provincias["Ceuta"]=["Ceuta"];
    provincias["Melilla"]=["Melilla"];
    let provinciaS=provincias[comunidad];
    return provinciaS;
}
function comentario(comunidad)
{//https://www.spotblue.com/es/news/regions-of-spain-autonomous-communities-facts/
    let comentarios=new Array()
    comentarios["Andaluci­a"]=["Andalucía encarna un tema tradicional como se ve en el flamenco baila y plazas de toros polémicos."];
    comentarios["Valencia"]=["Abarca la tercera ciudad más grande de España con el mismo nombre"];
    comentarios["Cataluña"]=["Joya de la corona de Cataluña es multicultural de Barcelona, la ciudad más visitada de España que atrae a gente de todo el mundo."];
    comentarios["Baleares"]=["Sentado en el mar Mediterráneo famosa, el granero fama Islas Baleares debido a vacaciones y la propiedad de ultramar puntos de acceso como Ibiza, Menorca, y Mallorca."];
    comentarios["Canarias"]=["La colección de Canarias establece los puntos de acceso de Lanzarote, La Plama, Tenerife, Fuerteventura, La Gomera, El Hirro, y Gran Caria."];
    comentarios["Galicia"]=["Los mariscos son una parte integral de su cocina local, y ofrece algunas variedades dignas de vino español."];
    comentarios["Pai­s Vasco"]=["País Vasco, sentado en la frontera con Francia, tiene su propio lenguaje y es muy independiente."];
    comentarios["Madrid"]=["Sentado en el centro de España, que es donde sucede todo y cualquier cosa, incluyendo la política, comercio turístico, economía, industria, y educación."];
    comentarios["Asturias"]=["Esperar temperaturas más bajas en Asturias porque esta deliciosa región se encuentra en la costa norte."];
    comentarios["Cantabria"]=["Una vez que llegue en Cantabria, dejar sus maletas y dirigirse a un restaurante para el plato local suntuosa de calamares fritos, junto con otras delicias de marisco."];
    comentarios["Murcia"]=["Como otra región en la que el nombre se refiere a la ciudad y la provincia más grande, Murcia cuenta con dos grandes reclamos a la fama."];
    comentarios["Navarra"]=["Con esta Comunidad Autónoma, no pensar tanto en las playas, pero más de los pueblos del interior a distancia gritando de las tradiciones y la cultura auténticas."];
    comentarios["La Rioja"]=["El amor por el vino español es notoria, y ninguna región anima a que más de La Rioja y sus cientos de bodegas de primer nivel."];
    comentarios["Aragon"]=["El punto de acceso para alojarse y explorar aquí es la capital, Zaragoza, el que grita de la historia."];
    comentarios["Castilla y Leon"]=["Como otra región interior, el foco de Castilla y León rodea historia y la cultura."];
    comentarios["Castilla-La Mancha"]=["Castilla La Mancha se encuentra cerca de Madrid, y juntos evocan un sentido cabal de la cultura y las tradiciones españolas."];
    comentarios["Extremadura"]=["Extremadura que se encuentra en la frontera con Portugal tiene grandes ciudades como Cáceres, cuya reputación de impresionante belleza es conocida en todo España."];
	 comentarios["Ceuta"]=["Es una ciudad autónoma española en la costa norte de África."];
	 comentarios["Melilla"]=["Ciudad autónoma española situada en el norte de África, a orillas del mar Mediterráneo."];
	 return comentarios[comunidad];
}
function addMensaje() 
{
	let titulo=$("#titulo").val();
	let comentario=$("#comentario").val();
	let radio=$('input[id=imagenMen]:checked').val();
	if (titulo.length>0 && comentario.length>0 && radio.length>0)
	{
		let c=$("usuario").text();
		let usuario=c.substr(c.indexOf(": ")+2);
		
		let TodoMen=$("div#TodoMen");
		let fieldset=$("<fieldset></fieldset>");

		let imagen = $("<img></img>");
		imagen.attr("src", "img/"+radio);
		imagen.css("width", "50");
		imagen.css("height", "50");
		imagen.css("float", "left");
		
		
		let h1Usuario=$("<h1></h1>").text(usuario);
		
		let strong=$("<strong></strong>").text(titulo);

		let p=$("<p></p>").text(comentario);

		fieldset.append(imagen);		
		fieldset.append(h1Usuario);
		fieldset.append(strong);
		fieldset.append(p);
		TodoMen.append(fieldset);
		OcultarAddMensaje();
	}
	
}