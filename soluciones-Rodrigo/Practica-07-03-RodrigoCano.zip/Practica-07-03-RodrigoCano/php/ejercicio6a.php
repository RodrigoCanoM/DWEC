<?php 

echo '{ "marcas":["LG","Samsung", "Panasonic", "Philips"] }';

?>