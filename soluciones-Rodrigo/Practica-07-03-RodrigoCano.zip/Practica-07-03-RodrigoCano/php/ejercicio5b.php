<?php 

$dato=fopen('php://input','r');
$valor=fgets($dato);
$televisores=simplexml_load_string($valor);
$marca=$televisores->marca;
$medida=$televisores->medida;

$precio=0;

switch($marca){ 
    case 'LG': 
		switch($medida){ 

			case '30': $precio= 599.99; break; 
			case '40': $precio= 699.99; break; 
			case '50': $precio= 799.99; break; 
            case '60': $precio= 899.99; break; 
            
		} 
	break; 
    case 'Samsung': 
		switch($medida){ 

			case '30': $precio= 299.99; break; 
			case '40': $precio= 399.99; break; 
			case '50': $precio= 499.99; break; 
            case '60': $precio= 599.99; break; 
            
		} 
    break; 
    case 'Panasonic': 
		switch($medida){ 

			case '30': $precio= 350.99; break; 
			case '40': $precio= 400.99; break; 
			case '50': $precio= 600.99; break; 
            case '60': $precio= 4000.99; break; 
            
		} 
    break; 
    case 'Philips': 
		switch($medida){ 

			case '30': $precio= 330.99; break; 
			case '40': $precio= 550.99; break; 
			case '50': $precio= 760.99; break; 
            case '60': $precio= 5209.99; break; 
            
		} 
	break;

}
header('Content-Type:text/xml');
echo '<televisor>
		       <marca>'.$marca.'</marca>
               <medida>'.$medida.'</medida>
               <precio>'.$precio.'</precio>
	</televisor>';
?>