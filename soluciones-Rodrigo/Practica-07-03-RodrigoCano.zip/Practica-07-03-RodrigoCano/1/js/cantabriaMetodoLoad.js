$(function(){
    cambio("txt/cantabria.txt");
})
function cambio(enlace){
    $("#contenido").load("http://localhost/Practica-07-03-RodrigoCano/1/"+ enlace);
}

