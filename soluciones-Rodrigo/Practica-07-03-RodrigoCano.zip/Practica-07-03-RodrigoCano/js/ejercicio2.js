$(window).on("load",inicio);

function inicio(){
    //if(document.readyState=="complete"){

    	$("#enviar").on("click",peticion);
    //}
}

function peticion(){
     let nombre=$("#nombre");
     let apellido=$("#apellidos");
     let modulo=$("#modulo");
     //nota=$("#nota");
    if(nombre.value !="" && apellido.value !="" && modulo.value !=""){
        nombre.disabled=true;
        apellido.disabled=true;
        modulo.disabled=true;
        console.log({nombre : nombre.val() , apellidos : apellido.val() , modulo : modulo.val() })
        $.get("php/ejercicio2.php", 
            {nombre : nombre.val() , apellidos : apellido.val() , modulo : modulo.val() }, 
            gestionarRespuesta);
        /*
        if(window.XMLHttpRequest){
            peticion_http=new XMLHttpRequest();
        }else if(window.ActiveXObject){
            peticion_http=new ActiveXObject("Microsoft.XMLHTTP");
        }
        $(peticion_http).on('readystatechange', gestionarRespuesta); 

        peticion_http.open("GET", "php/ejercicio2.php?nombre=" + nombre.value + "&apellidos=" + apellido.value + "&modulo=" + modulo.value, true);
        peticion_http.send(null);
        */
    }else{
        alert("Rellena todos los campos");
    }
}

function gestionarRespuesta(valor){ //(evento)
    /*
    if (evento.target.readyState == 4 && evento.target.status == 200) { 
        nombre.disabled=false;
        apellido.disabled=false;
        modulo.disabled=false;
        //nota.value=evento.target.responseText;
        $("#nota").val(peticion_http.responseText);
        */
        $("#nota").val(valor);
    //}
}
