//var peticion_http2;
$(window).on("load", inicio);

function inicio(){
  $.ajax("php/ejercicio5a.php",{success:obtenerDatos});
  let formulario = $("#formulario");
  $(formulario).on("change",obtenerPrecio);

}
function obtenerDatos(valor){
  console.log(valor);
  let marca=$(valor).find("marca");
  for (let i=0;i < $(marca).length;i++)
    $("#marca").append("<option>"+$(marca).eq(i).text()+"</option>");

  let medida=$(valor).find("medida");
  for (let i=0;i < $(medida).length;i++)
    $("#medida").append("<option>"+$(medida).eq(i).text()+"</option>");
}

function obtenerPrecio(){
  let marca = $("#marca").val();
  let medida = $("#medida").val();
  
/*
$.ajax("http://localhost/ejemplos/ejemplo-009/ejemplo-jquery-ajax-012.php",
{success:function(uno,estado,resultado){
  $(uno).find("datosalumnos").each(function(){
    $(this).find("alumno").each(function(){
      $("#respuesta").text($(this).find("nota").text());
    });
  });
}
,data:datos
,method:"POST"
,dataType:"xml"
}
);

*/
    let cadena =
    "<televisores><marca>" +
    marca +
    "</marca><medida>" +
    medida +
    "</medida></televisores>";

    $.ajax("php/ejercicio5b.php",
      {success:function(uno,estado,resultado)
        {
          console.log(cadena);
          console.log(uno);
          console.log(estado);
          console.log(resultado);
          $(uno).find("televisor").each(function()
          {
            $("#precio").val( $(this).find("precio").text() + " €" );
          } );
        }
      ,data : cadena
      ,method:"POST"
      ,dataType:"xml"
      }
      
    );

/*
    if (window.XMLHttpRequest){
      peticion_http2 =new XMLHttpRequest();
    }else if (window.ActiveXObject){
      try{
        peticion_http2 =new ActiveXObject("Microsoft.XMLHTTP");
      }catch(e){
       return false;
      }
    }
  $(peticion_http2).on('readystatechange', mostrarPrecio);

  peticion_http2.open("POST", "php/ejercicio5b.php", true);
  peticion_http2.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
  peticion_http2.setRequestHeader("Content-Length", cadena.length);
  peticion_http2.send(cadena);
  */
}
/*
function mostrarPrecio() {
  if (peticion_http2.readyState == 4 && peticion_http2.status == 200) {
    $("#precio").val(peticion_http2.responseText + " €");
  }
}
*/
