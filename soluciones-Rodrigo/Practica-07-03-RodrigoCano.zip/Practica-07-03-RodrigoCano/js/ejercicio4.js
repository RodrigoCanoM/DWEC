$(window).on("load",inicio);
 function inicio(){

    //if(document.readyState=="complete"){
        $("#enviar").on("click",enviarDatos);
    //}
}

//var solicitud;
function enviarDatos(){
    /*
    if(window.XMLHttpRequest)
        solicitud= new XMLHttpRequest();
    else if(window.ActiveXObject)
        solicitud= new ActiveXObject("Microsoft.XMLHTTP");
    */
    let nombre=$("#nombre").val();
    let apellido=$("#apellidos").val();
    let trabajo=$("#trabajo").val();

    let datos= new FormData();
    datos.append("nombre", nombre);
    datos.append("apellidos", apellido);
    datos.append("trabajo",trabajo);
    console.log(datos);
    $.ajax("php/ejercicio4.php",{ method:"POST",
        data:datos,
        complete:mostrar,
        contentType: false,
        processData: false
    });

    /*
    $(peticion_http).on('readystatechange', mostrar);

        solicitud.open("POST", "php/ejercicio4.php");
        solicitud.send(datos);
    */
}

function mostrar(respuesta){//()
    //if (solicitud.readyState==4) 
        //if (solicitud.status==200)
            //No------document.getElementById("sueldo").value=solicitud.responseText;
            //Si ---- $("#sueldo").val(peticion_http.responseText);
    console.log(respuesta.responseText);
    $("#sueldo").val(respuesta.responseText);
}