if (document.addEventListener)
	window.addEventListener("load",inicio)
else if (document.attachEvent)
    window.attachEvent("onload",inicio);
function inicio(){
	/*
    var txt = "";
    for (i = 0; i < dRegistrarse.length; i++) {
    txt = txt + dRegistrarse[i].value + "\n";
  		}
  	alert(txt);*/
  	//let btnCancelar=document.getElementById("cancelar");
  	//let btnAceptar=document.getElementById("aceptar");
      
      //Registrarse
    let btnRegistrase=document.getElementById("registrase");
    	//let dRegistrarse=document.getElementById("vRegistrase").children;
        let btnCancelarR=document.getElementById("cancelarReg");
  	    let btnAceptarR=document.getElementById("aceptarReg");    
        
        //let btnCancelarR=dRegistrarse[7];//cancelar de vRegistrase
    		//let btnAceptarR=dRegistrarse[6];//aceptar de vRegistrase
    
    //Entrar
	let btnEntrar=document.getElementById("entrar");
		//let dEntrar=document.getElementById("vEntrar").children;
			//let btnCancelarE=dEntrar[7];//cancelar de vEntrar
               //let btnAceptarE=dEntrar[6];//aceptar de vEntrar
        let btnCancelarE=document.getElementById("cancelarEnt");
        let btnAceptarE=document.getElementById("aceptarEnt");

    

    //Terminos
    let btnDefinicion=document.getElementById("addDefiniciones");
    
    //Localidades
    let btnLocalidad=document.getElementById("addLocalidades");
    
    //Coches
    let btnCoche=document.getElementById("addCoches");

    //changeProvincia
    //Comunidad
    let opciones=document.getElementById("comunidades");
    
    //Mensaje addMensaje
    let btnMensaje=document.getElementById("addMensaje");
    let btnCancelarMen=document.getElementById("cancelarMen");
    let btnAceptarM=document.getElementById("aceptarMen");
    //let radioMensaje=document.getElementById("imagenMen");

    if (document.addEventListener) {
    	
    	btnRegistrase.addEventListener("click",mostrarReg);
        btnCancelarR.addEventListener("click",ocultarReg);
       btnAceptarR.addEventListener("click",aceptarReg);
       
       btnEntrar.addEventListener("click",mostrarEnt);
       btnCancelarE.addEventListener("click",ocultarEnt);
       btnAceptarE.addEventListener("click",aceptarEnt);
        
       btnMensaje.addEventListener("click",MostrarAddMensaje);
       btnCancelarMen.addEventListener("click",OcultarAddMensaje);

       btnDefinicion.addEventListener("click",addDefinicion);
       
       btnLocalidad.addEventListener("click",addLocalidad);
       
       btnCoche.addEventListener("click",addCoche);

       opciones.addEventListener("change",changeProvincia);
       
       btnAceptarM.addEventListener("click",addMensaje);
       
       //radioMensaje.addEventListener("click",CambioImg);

    } else if (document.attachEvent){
       btnEntrar.attachEvent("onclick",mostrarEnt);
       btnCancelarE.attachEvent("onclick",ocultarEnt);
       btnAceptarE.attachEvent("onclick",aceptarEnt);
        
       btnRegistrase.attachEvent("onclick",mostrarReg);
       btnCancelarR.attachEvent("onclick",ocultarReg);
       btnAceptarR.attachEvent("onclick",aceptarReg);
        
       btnMensaje.attachEvent("onclick",MostrarAddMensaje);
       btnCancelarMen.attachEvent("onclick",OcultarAddMensaje);

       btnDefinicion.attachEvent("onclick",addDefinicion);
       
       btnLocalidad.attachEvent("onclick",addLocalidad);
       
       btnCoche.attachEvent("onclick",addCoche);

       opciones.attachEvent("onchange",changeProvincia);
       
       btnAceptarM.attachEvent("onclick",addMensaje);
       
       //radioMensaje.attachEvent("onclick",CambioImg);
    }
    
}
var ValorImg="";
/*
function CambioImg(value) 
{
	
	alert(value);
	let valor=document.getElementById("imagenMen").value;
	alert(valor);
	ValorImg=valor;
	
	alert("ssss");
}*/

function mostrarReg()
{
    document.getElementById("vRegistrase").setAttribute("open",true);
}
function ocultarReg()
{
    document.getElementById("vRegistrase").removeAttribute("open");
}
var cerrarS="Cerrar Sesion";
var entrarS="Entrar";
var usuario="Usuario";
function mostrarEnt()
{
    let valor=document.getElementById("entrar").value;
    if (valor==entrarS)
    {
        document.getElementById("vEntrar").setAttribute("open",true);
    }
    else 
    {
        document.getElementById("entrar").value=entrarS;
        document.getElementById("usuario").textContent=usuario;
        botonMensaje=false;
    }
    
}
function ocultarEnt()
{
    document.getElementById("vEntrar").removeAttribute("open");
}
function aceptarReg()
{
    let mensaje="";
    let Cnombre=/^[A-Z]{3}[A-Z0-9]{5,9}$/i;
    let Ccontrasenya=/^[A-Z]{2}[A-Z\d_]{5,11}[A-Z\d]$/i;
    let nombre=document.getElementById("nombreReg").value;
    let pass=document.getElementById("passReg").value;
    if (!Cnombre.test(nombre))
    	mensaje+="Error en nombre \n";
    if(!Ccontrasenya.test(pass))
    	mensaje+="Error en contraseña \n";
    if (mensaje.length>0)
    {
      alert(mensaje);
      return false;
    }
    else
    {
        ocultarReg();
        let x=nombre+"="+pass+";expires=Thu;01 Jan 2030 00:00:00 UTC; path=/";
     	  document.cookie=x;
     	  //alert("cookie:")
     	  //alert(document.cookie);
        
         
    }
}
var botonMensaje=false;

function aceptarEnt() {
    let nombre=document.getElementById("nombreEnt").value;
    //alert(nombre);
    let pass=document.getElementById("passEnt").value;
    //alert(pass);
    //let nombre=dRegistrarse[1].value//nombre;
    //let pass=dRegistrarse[3].value//pass;
    let cadena=document.cookie;
    //alert(cadena);
    //alert(nombre+":"+pass)
    let posicion=cadena.indexOf(nombre+"="+pass);
    if (posicion==-1)
    {
        alert("Error, el usuario no existe")
        return false;	
    }
    else {
        //alert("Si");
        document.getElementById("usuario").textContent= usuario+": "+nombre;
        document.getElementById("entrar").value=cerrarS;
        botonMensaje=true;
        ocultarEnt();
    }
}
function MostrarAddMensaje(){
    if (botonMensaje)
    {
        document.getElementById("vMensaje").setAttribute("open",true);
    }
}
function OcultarAddMensaje(){
    document.getElementById("vMensaje").removeAttribute("open");
}

function addDefinicion(){
    let palabra=document.getElementById("palabra").value;
    let concepto=document.getElementById("concepto").value;
    if (palabra.length>0 && concepto.length>0)
    {
        let lis=document.querySelector("#definiciones");
        
        let posicion=buscar(palabra);
        if (posicion==-1)
        {
        		let nuevoLi=document.createElement("li");
        		let nuevoOl=document.createElement("ol");
        		let termino=document.createTextNode(palabra);

        		let nuevoLiDef=document.createElement("li");
        		let definicion=document.createTextNode(concepto);
        
        		nuevoLiDef.appendChild(definicion);
        		nuevoOl.appendChild(nuevoLiDef);

        		nuevoLi.appendChild(termino);
        		nuevoLi.appendChild(nuevoOl);
        		lis.appendChild(nuevoLi);
        }
        else {
        		let el=document.querySelectorAll("#definiciones>li");
        		
        		let nuevoLiDef=document.createElement("li");
        		let definicion=document.createTextNode(concepto);
        		nuevoLiDef.appendChild(definicion)
        		
        		let li=el.item(posicion);
        		oldOl=li.querySelector("ol");
        		oldOl.appendChild(nuevoLiDef);
        }
        
        //alert(nuevoLi.firstChild.textContent);
        
        
    }
    else alert("Error: Palabra o concepto vacio")
}
function buscar(palabra)
{
	
	let el=document.querySelectorAll("#definiciones>li");
   for (let indice=0; indice < el.length ; indice++ )
   {
   	if (el.item(indice).firstChild.textContent==palabra)
   		return indice;
   }
	return -1;
}
function addLocalidad() 
{
	let lis=document.querySelector("#localidades");
	let newLocalidad=document.getElementById("localidad").value;
	let el=document.querySelectorAll("#localidades>li");
	if(newLocalidad.length>0)
	{
		let localidad=document.createTextNode(newLocalidad);
		let nuevoLi=document.createElement("li");
		nuevoLi.appendChild(localidad);
		let posicion=posicionLocalidad(newLocalidad);
		if (posicion!=-1)
			lis.insertBefore(nuevoLi,el.item(posicion));
	}
	else alert("Error: Localidad vacia");
}
function posicionLocalidad(newLocalidad) {
    let el=document.querySelectorAll("#localidades>li");
    num=0;
	for (let indice=0; indice < el.length ; indice++ )
   {
   	if (el.item(indice).textContent==newLocalidad)
   		return -1;
       if (el.item(indice).textContent>newLocalidad)
       {
        num=indice+1;
       }
       
   }
	return num;
}

function addCoche() 
{
	let trs=document.querySelector("#coches");
	let marca=document.getElementById("marca").value;
	let modelo=document.getElementById("modelo").value;
	let precio=document.getElementById("precio").value;
	let testPrecio=/^[0-9]+$/i;
	if (marca.length>0 && modelo.length>0 && testPrecio.test(precio))
	{
		let posicion=posicionCoche(marca,modelo);
		if (posicion!=-1)
		{
			let nuevoTr=document.createElement("tr");
			nuevoTr.appendChild(rellenarTr(marca));
			nuevoTr.appendChild(rellenarTr(modelo));
			nuevoTr.appendChild(rellenarTr(precio));
			
			let tr=document.querySelectorAll("#coches>tr");
			trs.insertBefore(nuevoTr,tr.item(posicion));
			
		}
	}
	else 
	{
		let mensaje="";
		if (!testPrecio.test(precio))
			mensaje+="Error: El precio no es un número \n";
		if (marca.length==0 || modelo.length==0)
			mensaje+="Error: La marca o el modelo esta vacio \n";
		alert(mensaje);
	}
}
function posicionCoche(marca,modelo) {
	let tr=document.querySelectorAll("#coches>tr");
	let num=tr.length;
	let ultimo="";
	let contador=0;
	for (let indice=0; indice < tr.length ; indice++ )
   {
   	let tds=tr.item(indice).querySelectorAll("td");
   	if (tds.item(0).textContent==marca && tds.item(1).textContent==modelo)
   		return -1;
   	if (tds.item(0).textContent>=marca)
   	{//Tengo que separar
   			if (contador==0)
   			{
					contador++;
					ultimo=tds.item(0).textContent;
				}
				if(ultimo<tds.item(0).textContent || marca<tds.item(0).textContent )
				{
					return indice;				
				}
				if (ultimo>=tds.item(0).textContent) {
					num=indice+1;
   				ultimo=tds.item(0).textContent;
   				
   				if(tds.item(1).textContent>modelo)
   				{
						return indice; 			
   				}
   			}	
   	}	
   }
	return num;
}
function rellenarTr(relleno) {
	let rellenoT=document.createTextNode(relleno);
	let td=document.createElement("td");
	td.appendChild(rellenoT);
	return td;
}
var oldProv="";

function changeProvincia(){
    let comunidad=document.getElementById("comunidades").value;
    if (comunidad!=oldProv)
    {
        oldProv=comunidad;
        drobProvincias();
        addProvicias(comunidad);
        //
        //alert(comentario(comunidad));
        document.getElementById("comentarioProv").textContent=comentario(comunidad);
    }
}

function drobProvincias(){
    
    let select=document.querySelector("select#provincia");
    let ops=select.querySelectorAll("option");
    
	for (let indice=0;indice < ops.length;indice++)
        select.removeChild(ops.item(indice));
}
function addProvicias(comunidad)
{
    let select=document.querySelector("select#provincia");
    let provincias=provicias(comunidad);
    for (let indice=0; indice < provincias.length ; indice++ )
    {
        let option=document.createElement("option");
        let provincia=document.createTextNode(provincias[indice])
        option.appendChild(provincia);
        select.appendChild(option);
    }
}
function provicias(comunidad){
    let provincias=new Array();
    provincias["Andaluci­a"]=["Almería", "Cádiz", "Córdoba", "Granada", "Huelva", "Jaén", "Málaga", "Sevilla",];//
    provincias["Aragon"]=["Huesca", "Teruel", "Zaragoza"];//
    provincias["Asturias"]=["Oviedo"];//
    provincias["Baleares"]=["Palma de Mallorca"];//
    provincias["Pai­s Vasco"]=["Bilbao","San Sebastián","Vitoriaa"];//
    provincias["Canarias"]=["Santa Cruz de Tenerife","Las Palmas de Gran Canaria"];//
    provincias["Cantabria"]=["Santander"];//
    provincias["Castilla-La Mancha"]=["Albacete","Ciudad Real", "Cuenca","Guadalajara","Toledo"];//
    provincias["Castilla y Leon"]=["Ávila", "Burgos", "León", "Salamanca", "Segovia", "Soria", "Valladolid", "Zamora"];//
    provincias["Cataluña"]=["Barcelona", "Gerona", "Lérida", "Tarragona"];//
    provincias["Extremadura"]=["Badajoz","Cáceres"];//
    provincias["Galicia"]=["La Coruña", "Lugo", "Orense", "Pontevedra"];//
    provincias["Madrid"]=["Madrid"];//
    provincias["Murcia"]=["Murcia"];//
    provincias["Navarra"]=["Pamplona"];//
    provincias["La Rioja"]=["Logroño"];//
    provincias["Valencia"]=["Alicante","Castellón de la Plana", "Valencia"];//
    provincias["Ceuta"]=["Ceuta"];
    provincias["Melilla"]=["Melilla"];
    let provinciaS=provincias[comunidad];
    return provinciaS;
}
function comentario(comunidad)
{//https://www.spotblue.com/es/news/regions-of-spain-autonomous-communities-facts/
    let comentarios=new Array()
    comentarios["Andaluci­a"]=["Andalucía encarna un tema tradicional como se ve en el flamenco baila y plazas de toros polémicos."];
    comentarios["Valencia"]=["Abarca la tercera ciudad más grande de España con el mismo nombre"];
    comentarios["Cataluña"]=["Joya de la corona de Cataluña es multicultural de Barcelona, la ciudad más visitada de España que atrae a gente de todo el mundo."];
    comentarios["Baleares"]=["Sentado en el mar Mediterráneo famosa, el granero fama Islas Baleares debido a vacaciones y la propiedad de ultramar puntos de acceso como Ibiza, Menorca, y Mallorca."];
    comentarios["Canarias"]=["La colección de Canarias establece los puntos de acceso de Lanzarote, La Plama, Tenerife, Fuerteventura, La Gomera, El Hirro, y Gran Caria."];
    comentarios["Galicia"]=["Los mariscos son una parte integral de su cocina local, y ofrece algunas variedades dignas de vino español."];
    comentarios["Pai­s Vasco"]=["País Vasco, sentado en la frontera con Francia, tiene su propio lenguaje y es muy independiente."];
    comentarios["Madrid"]=["Sentado en el centro de España, que es donde sucede todo y cualquier cosa, incluyendo la política, comercio turístico, economía, industria, y educación."];
    comentarios["Asturias"]=["Esperar temperaturas más bajas en Asturias porque esta deliciosa región se encuentra en la costa norte."];
    comentarios["Cantabria"]=["Una vez que llegue en Cantabria, dejar sus maletas y dirigirse a un restaurante para el plato local suntuosa de calamares fritos, junto con otras delicias de marisco."];
    comentarios["Murcia"]=["Como otra región en la que el nombre se refiere a la ciudad y la provincia más grande, Murcia cuenta con dos grandes reclamos a la fama."];
    comentarios["Navarra"]=["Con esta Comunidad Autónoma, no pensar tanto en las playas, pero más de los pueblos del interior a distancia gritando de las tradiciones y la cultura auténticas."];
    comentarios["La Rioja"]=["El amor por el vino español es notoria, y ninguna región anima a que más de La Rioja y sus cientos de bodegas de primer nivel."];
    comentarios["Aragon"]=["El punto de acceso para alojarse y explorar aquí es la capital, Zaragoza, el que grita de la historia."];
    comentarios["Castilla y Leon"]=["Como otra región interior, el foco de Castilla y León rodea historia y la cultura."];
    comentarios["Castilla-La Mancha"]=["Castilla La Mancha se encuentra cerca de Madrid, y juntos evocan un sentido cabal de la cultura y las tradiciones españolas."];
    comentarios["Extremadura"]=["Extremadura que se encuentra en la frontera con Portugal tiene grandes ciudades como Cáceres, cuya reputación de impresionante belleza es conocida en todo España."];
	 comentarios["Ceuta"]=["Es una ciudad autónoma española en la costa norte de África."];
	 comentarios["Melilla"]=["Ciudad autónoma española situada en el norte de África, a orillas del mar Mediterráneo."];
	 return comentarios[comunidad];
}
function addMensaje() 
{
	let titulo=document.getElementById("titulo").value;
	let comentario=document.getElementById("comentario").value;
	//alert("antes");//document.querySelector("#imagenMen :radio");
	let radio=document.querySelector('input[id=imagenMen]:checked').value 
	//alert(titulo+":"+comentario+":"+radio);
	if (titulo.length>0 && comentario.length>0 && radio.length>0)
	{
		let c=document.getElementById("usuario").textContent;
		let usuario=c.substr(c.indexOf(": ")+2);
		
		let TodoMen=document.querySelector("div#TodoMen");
		let fieldset=document.createElement("fieldset");

		let imagen = document.createElement("img");
		imagen.setAttribute("src", "img/"+radio);
		imagen.setAttribute("width", "50");
		imagen.setAttribute("height", "50");
		
		
		let h1Usuario=document.createElement("h1");
		let usuarioT=document.createTextNode(usuario);
		h1Usuario.appendChild(usuarioT);
		
		let strong=document.createElement("strong");
		let tituloT=document.createTextNode(titulo);
		strong.appendChild(tituloT)
		
		let p=document.createElement("p");
		let comentarioT=document.createTextNode(comentario);
		p.appendChild(comentarioT)
		
		fieldset.appendChild(imagen);		
		fieldset.appendChild(h1Usuario);
		fieldset.appendChild(strong);
		fieldset.appendChild(p);
		TodoMen.appendChild(fieldset);
		OcultarAddMensaje();
	}
	
}






