<?php 

/* $marcas=(object)array('Sony','Philips', 'Panasonic', 'Bosch');
$marcas=json_encode($marcas);
//echo $marcas; */

echo '{ "marcas":["Sony","Philips", "Panasonic", "Bosch"] }';

?>