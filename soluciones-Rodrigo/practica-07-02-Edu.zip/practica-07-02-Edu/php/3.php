<?php

   echo rand(1000,3250)." €";  

?>