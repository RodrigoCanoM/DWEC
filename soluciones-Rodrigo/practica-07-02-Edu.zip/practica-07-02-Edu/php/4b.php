<?php 

$dato=fopen('php://input','r');
$valor=fgets($dato);
$televisores=simplexml_load_string($valor);
$marca=$televisores->marca;
$medida=$televisores->medida;



switch($marca){ 
    case 'Sony': 
		switch($medida){ 

			case '40': echo 399.99; break; 
			case '60': echo 699.99; break; 
			case '80': echo 899.99; break; 
            case '50': echo 599.99; break; 
            
		} 
	break; 
    case 'Samsumg': 
		switch($medida){ 

			case '40': echo 499.99; break; 
			case '60': echo 599.99; break; 
			case '80': echo 999.99; break; 
            case '50': echo 699.99; break; 
            
		} 
    break; 
    case 'Panasonic': 
		switch($medida){ 

			case '40': echo 299.99; break; 
			case '60': echo 599.99; break; 
			case '80': echo 799.99; break; 
            case '50': echo 499.99; break; 
            
		} 
    break; 
    case 'LG': 
		switch($medida){ 

			case '40': echo 399.99; break; 
			case '60': echo 699.99; break; 
			case '80': echo 899.99; break; 
            case '50': echo 599.99; break; 
            
		} 
	break; 
} 
?>