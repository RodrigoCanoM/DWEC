<?php

    $nombre=$_REQUEST["nombre"];
    $apellidos=$_REQUEST["apellidos"];
    $modulo=$_REQUEST["modulo"];

    echo rand(4,10);

?>