<?php

$entrada=fopen('php://input','r');
$datos= fgets($entrada);
$datos= json_decode($datos,true);
$resultado=array('marca'=>$datos['marca'],'elec'=>$datos['elec']);

$resultado["ancho"]=rand(30,80);
$resultado["alto"]=rand(20,60);
$resultado["fondo"]=rand(30,75);

$resultado=json_encode($resultado);
echo $resultado;

?>