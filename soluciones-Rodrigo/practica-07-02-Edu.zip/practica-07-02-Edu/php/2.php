<?php

$nota=$_REQUEST["nota"];

switch($nota){

    case ($nota<5 && $nota>-1) : $nota="SUSPENSO"; break;
    case ($nota==5) : $nota="SUFICIENTE"; break;
    case ($nota==6) : $nota="BIEN"; break;
    case ($nota==7 || $nota==8) : $nota="NOTABLE"; break;
    case ($nota==9 || $nota==10) : $nota="SOBRESALIENTE"; break;

    default: $nota="Introduzca una nota del 0-10";

}

echo $nota


?>