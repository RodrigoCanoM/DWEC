<?php 

    header("Content-Type:text/xml");
    
    echo '<televisor>
            <marcas>
		        <marca>Sony</marca>
			    <marca>Samsung</marca>
		        <marca>Panasonic</marca>
		        <marca>LG</marca>
		   </marcas>	
		   <medidas>
               <medida>40</medida>
               <medida>60</medida>
               <medida>80</medida>
               <medida>50</medida>
           </medidas>	
		</televisor>';
		
?>