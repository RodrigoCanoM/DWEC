
var peticion_http;
window.addEventListener("load", ()=>{
    inicio();
});

const inicio = () => {

    const formulario=document.getElementById("formulario");
    formulario.addEventListener("click", e =>{
       if(e.target.id=="obtenerSueldo") obtenerSueldo();
       e.stopPropagation();
    });

 }

const obtenerSueldo = () =>{

    var formulario=document.getElementById("formulario");
    var datos=new FormData(formulario);
   /*  var nombre=document.getElementById("nombre").value;
    var apellidos=document.getElementById("apellidos").value;
    var puesto=document.getElementById("puesto").value;

    datos.append("nombre",nombre);
    datos.append("apellidos",apellidos);
    datos.append("puesto",puesto);
 */
console.log(datos.get("puesto"));
    if(window.XMLHttpRequest){
		peticion_http=new XMLHttpRequest();
  	}
    	else if(window.ActiveXobject){
	     	try{
		      	peticion_http=new ActiveXobject("Microsoft.XMLHTTP");
	        	}
		    catch(e){
		     }
    }

    if(document.addEventListener){
      peticion_http.addEventListener("readystatechange", ()=>mostrarFichero());
    }
    else if(document.attachEvent){
      peticion_http.attachEvent("onreadystatechange", ()=>mostrarFichero());
    }
      peticion_http.open("POST","./php/3.php", true);
      peticion_http.send(datos); 
  }
  
  const mostrarFichero=()=>{
    if(peticion_http.readyState==4 && peticion_http.status==200){
      document.getElementById("sueldo").value=peticion_http.responseText;
    }
  }

   
    

