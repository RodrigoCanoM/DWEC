var peticion_http;
var peticion_http2;
window.addEventListener("load", () => {
  inicio();
});

const inicio = () => {
  obtenerDatos();
  const formulario = document.getElementById("formulario");
  formulario.addEventListener("click", (e) => {
    if (e.target.id == "obtenermedidas") obtenerMedidas();
    e.stopPropagation();
  });
};

const obtenerDatos = () => {
  if (window.XMLHttpRequest) {
    peticion_http = new XMLHttpRequest();
  } else if (window.ActiveXobject) {
    try {
      peticion_http = new ActiveXobject("Microsoft.XMLHTTP");
    } catch (e) {}
  }

  if (document.addEventListener) {
    peticion_http.addEventListener("readystatechange", () => cargarDatos());
  } else if (document.attachEvent) {
    peticion_http.attachEvent("onreadystatechange", () => cargarDatos());
  }
  peticion_http.open("GET", "./php/5a.php", true);
  peticion_http.setRequestHeader("Content-Type", "application/json");
  peticion_http.send();
};

const cargarDatos = () => {
  if (peticion_http.readyState == 4 && peticion_http.status == 200) {
    var jsonMarcas = JSON.parse(peticion_http.responseText);
    var marcas = document.getElementById("marcas");

    jsonMarcas["marcas"].forEach((e) => {
      var optionMarca = document.createElement("option");
      optionMarca.textContent = e;
      marcas.appendChild(optionMarca);
    });
  }
};

const obtenerMedidas = () => {
  var marca = document.getElementById("marcas").value;
  var elec = document.getElementById("elecs").value;
  var datos = {
    marca: marca,
    elec: elec,
  };

  if (window.XMLHttpRequest) {
    peticion_http2 = new XMLHttpRequest();
  } else if (window.ActiveXobject) {
    try {
      peticion_http2 = new ActiveXobject("Microsoft.XMLHTTP");
    } catch (e) {}
  }

  if (document.addEventListener) {
    peticion_http2.addEventListener("readystatechange", () => mostrarMedidas());
  } else if (document.attachEvent) {
    peticion_http2.attachEvent("onreadystatechange", () => mostrarMedidas());
  }
  peticion_http2.open("POST", "./php/5b.php", true);
  peticion_http2.setRequestHeader("Content-Type", "application/json");
  peticion_http2.send(JSON.stringify(datos));
};

const mostrarMedidas = () => {
  if (peticion_http2.readyState == 4 && peticion_http2.status == 200) {
    var jsonMedidas = JSON.parse(peticion_http2.responseText);

    document.getElementById("ancho").value = jsonMedidas["ancho"] + " cm";
    document.getElementById("alto").value = jsonMedidas["alto"] + " cm";
    document.getElementById("fondo").value = jsonMedidas["fondo"] + " cm";
  }
};
