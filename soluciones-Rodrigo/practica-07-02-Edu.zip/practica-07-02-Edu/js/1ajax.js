
var peticion_http;
window.addEventListener("load", ()=>{
    inicio();
});

const inicio = () => {

    const formulario=document.getElementById("formulario");
    formulario.addEventListener("click", e =>{
       if(e.target.id=="obtenerNota") obtenerNota();
       e.stopPropagation();
    });

 }

const obtenerNota = () =>{

    var nombre=document.getElementById("nombre").value;
    var apellidos=document.getElementById("apellidos").value;
    var modulo=document.getElementById("modulo").value;

    cadena="?nombre="+nombre+"&apellidos="+apellidos+"&modulo="+modulo;
    console.log(cadena);
    
    if(window.XMLHttpRequest){
		peticion_http=new XMLHttpRequest();
  	}
    	else if(window.ActiveXobject){
	     	try{
		      	peticion_http=new ActiveXobject("Microsoft.XMLHTTP");
	        	}
		    catch(e){
		     }
    }

    if(document.addEventListener){
      peticion_http.addEventListener("readystatechange", ()=>mostrarFichero());
    }
    else if(document.attachEvent){
      peticion_http.attachEvent("onreadystatechange", ()=>mostrarFichero());
    }
      peticion_http.open("GET","./php/1.php"+cadena, true);
      peticion_http.send(); 
  }
  
  const mostrarFichero=()=>{
    if(peticion_http.readyState==4 && peticion_http.status==200){
      document.getElementById("nota").value=peticion_http.responseText;
    }
  }

   
    

