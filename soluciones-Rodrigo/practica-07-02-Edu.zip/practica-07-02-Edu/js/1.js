var peticion_http;
document.addEventListener("DOMContentLoaded", () => {
    inicio();
  });

  const inicio = () => {

    const formulario=document.getElementById("formulario");

     formulario.addEventListener("click", e =>{

       if(e.target.id=="obtenerNota") obtenerFicheros();
       e.stopPropagation();
    });

 }

  const obtenerFicheros=()=>{
	
	if(window.XMLHttpRequest){
		peticion_http=new XMLHttpRequest();
	}
	else if(window.ActiveXobject){
		try{
			peticion_http=new ActiveXobject("Microsoft.XMLHTTP");
		}
		catch(e){
		}
	}
	
	if(document.addEventListener){
		peticion_http.addEventListener("readystatechange", ()=>mostrarFichero());
	}
	else if(document.attachEvent){
		peticion_http.attachEvent("onreadystatechange", ()=>mostrarFichero());
	}
    peticion_http.open("GET","../php/1.php", true);
	peticion_http.send(); 
}

const mostrarFichero=()=>{
	if(peticion_http.readyState==4 && peticion_http.status==200){
	   console.log(peticion_http.responseText);
	}
}