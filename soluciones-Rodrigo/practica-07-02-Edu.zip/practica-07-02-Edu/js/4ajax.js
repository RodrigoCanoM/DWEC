var peticion_http;
var peticion_http2;
window.addEventListener("load", () => {
  inicio();
});

const inicio = () => {
  obtenerDatos();
  const formulario = document.getElementById("formulario");
  formulario.addEventListener("click", (e) => {
    if (e.target.id == "obtenerprecio") obtenerPrecio();
    e.stopPropagation();
  });
};

const obtenerDatos = () => {
  if (window.XMLHttpRequest) {
    peticion_http = new XMLHttpRequest();
  } else if (window.ActiveXobject) {
    try {
      peticion_http = new ActiveXobject("Microsoft.XMLHTTP");
    } catch (e) {}
  }

  if (document.addEventListener) {
    peticion_http.addEventListener("readystatechange", () => cargarDatos());
  } else if (document.attachEvent) {
    peticion_http.attachEvent("onreadystatechange", () => cargarDatos());
  }
  peticion_http.open("GET", "./php/4a.php", true);
  peticion_http.setRequestHeader(
    "Content-Type",
    "application/x-www-form-urlencoded"
  );
  peticion_http.overrideMimeType("text/xml");
  peticion_http.send();
};

const cargarDatos = () => {
  if (peticion_http.readyState == 4 && peticion_http.status == 200) {
    var xmlTv = peticion_http.responseXML;

    var marcas = xmlTv.getElementsByTagName("marca");
    var medidas = xmlTv.getElementsByTagName("medida");
    var listaMarcas = document.getElementById("marca");
    var listaMedidas = document.getElementById("medida");

    for (var i = 0; i < marcas.length; i++) {
      var optionMarca = document.createElement("option");
      var optionMedida = document.createElement("option");

      optionMarca.textContent = marcas[i].textContent;
      optionMedida.textContent = medidas[i].textContent + " pulgadas";

      listaMarcas.appendChild(optionMarca);
      listaMedidas.appendChild(optionMedida);
    }
  }
};

const obtenerPrecio = () => {
  var marca = document.getElementById("marca").value;
  var medida = document.getElementById("medida").value.split(" ", 1);
  var tvXML =
    "<televisores><marca>" +
    marca +
    "</marca><medida>" +
    medida +
    "</medida></televisores>";

  if (window.XMLHttpRequest) {
    peticion_http2 = new XMLHttpRequest();
  } else if (window.ActiveXobject) {
    try {
      peticion_http2 = new ActiveXobject("Microsoft.XMLHTTP");
    } catch (e) {}
  }

  if (document.addEventListener) {
    peticion_http2.addEventListener("readystatechange", () => mostrarPrecio());
  } else if (document.attachEvent) {
    peticion_http2.attachEvent("onreadystatechange", () => mostrarPrecio());
  }
  peticion_http2.open("POST", "./php/4b.php", true);
  peticion_http2.setRequestHeader(
    "Content-Type",
    "application/x-www-form-urlencoded"
  );
  peticion_http2.setRequestHeader("Content-Length", tvXML.length);
  peticion_http2.send(tvXML);
};

const mostrarPrecio = () => {
  if (peticion_http2.readyState == 4 && peticion_http2.status == 200) {
    var precio = peticion_http2.responseText;
    document.getElementById("precio").value = precio + " €";
  }
};
