
var peticion_http;
window.addEventListener("load", ()=>{
    inicio();
});

const inicio = () => {

    const formulario=document.getElementById("formulario");
    formulario.addEventListener("click", e =>{
       if(e.target.id=="obtenerNota") obtenerNota();
       e.stopPropagation();
    });

 }

const obtenerNota = () =>{

    var nombre=document.getElementById("nombre").value;
    var apellidos=document.getElementById("apellidos").value;
    var modulo=document.getElementById("modulo").value;
    var nota=document.getElementById("notanumber").value;

    cadena="nombre="+nombre+"&apellidos="+apellidos+"&modulo="+modulo+"&nota="+nota;
    console.log(cadena);
    
    if(window.XMLHttpRequest){
		peticion_http=new XMLHttpRequest();
  	}
    	else if(window.ActiveXobject){
	     	try{
		      	peticion_http=new ActiveXobject("Microsoft.XMLHTTP");
	        	}
		    catch(e){
		     }
    }

    if(document.addEventListener){
      peticion_http.addEventListener("readystatechange", ()=>mostrarFichero());
    }
    else if(document.attachEvent){
      peticion_http.attachEvent("onreadystatechange", ()=>mostrarFichero());
    }
      peticion_http.open("POST","./php/2.php", true);
      peticion_http.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
      peticion_http.send(cadena); 
  }
  
  const mostrarFichero=()=>{
    if(peticion_http.readyState==4 && peticion_http.status==200){
      document.getElementById("notanombre").value=peticion_http.responseText;
    }
  }

   
    

