$(window).on("load",inicio);
 function inicio(){

    if(document.readyState=="complete"){
        $("#enviar").on("click",enviarDatos);
    }
}

var solicitud;
function enviarDatos(){

    let nombre=$("#nombre").val();
    let apellido=$("#apellidos").val();
    let trabajo=$("#trabajo").val();


    let datos= new FormData();
    datos.append("nombre", nombre);
    datos.append("apellidos", apellido);
    datos.append("trabajo",trabajo);


    let inicial={
        method:"POST",
        //headers:{"Content-Type":"application/x-www-form-urlencoded"},
        body: datos
    }
    fetch("php/ejercicio4.php", inicial)
        .then(correcto)
        .catch(error);
}

function correcto(response){
    if (response.ok) {
        response.text().then(gestionarRespuesta);
    }
}

function error()
{
    $("#sueldo").val("Error");
}

function gestionarRespuesta(dato)
{
    $("#sueldo").val(dato);
}