$(window).on("load",inicio);
var peticion_http;
var nombre;
var apellido;
var modulo;
var nota;
//var textNota;

function inicio(){
    if(document.readyState=="complete"){
        $("#enviar").on("click",peticion);
    }
}

function peticion(){
    nombre=$("#nombre").val();
    apellido=$("#apellidos").val();
    modulo=$("#modulo").val();
    nota=$("#nota").val();
    //textNota=$("#texto");
    if(nombre !="" && apellido!="" && modulo !="" && nota>=0 && nota<=10){
        nombre.disabled=true;
        apellido.disabled=true;
        modulo.disabled=true;
        nota.disabled=true;
        

        let inicial={
            method:"POST",
            headers:{"Content-Type":"application/x-www-form-urlencoded"},
            body: "nombre="+nombre+"&apellidos="+apellido+"&modulo="+modulo+"&nota="+nota
                   //datos
        }
        fetch("php/ejercicio3.php", inicial)
            .then(correcto)
            .catch(error);

    }else{
        alert("Rellena todos los campos y la nota es de 0 a 10");
    }
}

function correcto(response){
    if (response.ok) {
        response.text().then(gestionarRespuesta)
    }
}

function error()
{
    $("#texto").val("Error");
}

function gestionarRespuesta(dato)
{
    $("#texto").val(dato);
}