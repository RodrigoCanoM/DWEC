$(window).on("load", inicio);

function inicio(){


  let inicial={
        method:"GET",
        headers:{"Content-Type":"application/x-www-form-urlencoded"}//,
        //body: datos
    }
    fetch("php/ejercicio5a.php", inicial)
        .then(correctoObtenerDatos)
        .catch(errorObtenerDatos);



  //$.ajax("php/ejercicio5a.php",{success:obtenerDatos});
  let formulario = $("#formulario");
  $(formulario).on("change",obtenerPrecio);

}

function correctoObtenerDatos(response){
    if (response.ok) {
        response.text().then(mostrarListas)
    }
}

function errorObtenerDatos()
{
    $("#marca").append("<option>Error</option>");
    $("#medida").append("<option>Error</option>");
}

function mostrarListas(dato)
{
    
    let parser = new DOMParser();
    let xml = parser.parseFromString(dato, "application/xml"); 

    let marca=$(xml).find("marca");
      for (let i=0;i < $(marca).length;i++)
        $("#marca").append("<option>"+$(marca).eq(i).text()+"</option>");

    let medida=$(xml).find("medida");
      for (let i=0;i < $(medida).length;i++)
        $("#medida").append("<option>"+$(medida).eq(i).text()+"</option>");


}


function obtenerPrecio(){
  let marca = $("#marca").val();
  let medida = $("#medida").val();
  let cadena =
    "<televisores><marca>" +
    marca +
    "</marca><medida>" +
    medida +
    "</medida></televisores>";

  let inicial={
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body: cadena
    }
    fetch("php/ejercicio5b.php", inicial)
        .then(correcto)
        .catch(error);
};

function correcto(response){
    if (response.ok) 
      response.text().then(mostrarPrecio);
}

function error()
{
    $("#precio").val("Error");
}

function mostrarPrecio(dato)
{
    $("#precio").val(dato+" €");
}

