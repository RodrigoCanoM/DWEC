$(window).on("load",inicio);
var peticion_http;
var nombre;
var apellido;
var modulo;
//var nota;

function inicio(){
    if(document.readyState=="complete"){

    	$("#enviar").on("click",peticion);
    }
}

function peticion(){
     nombre=$("#nombre");
     apellido=$("#apellidos");
     modulo=$("#modulo");
     //nota=$("#nota");
    if(nombre.value !="" && apellido.value !="" && modulo.value !=""){
        nombre.disabled=true;
        apellido.disabled=true;
        modulo.disabled=true;



        let inicial={
            method:"GET",
            headers:{"Content-Type":"application/x-www-form-urlencoded"},
        }
        fetch("php/ejercicio2.php?nombre=" + nombre.value + "&apellidos=" + apellido.value + "&modulo=" + modulo.value, inicial)
            .then(correcto)
            .catch(error);



    }else{
        alert("Rellena todos los campos");
    }
}

function correcto(response){
    if (response.ok) {
        response.text().then(gestionarRespuesta)
    }
}
function gestionarRespuesta(dato)
{
    $("#nota").val(dato);
}
function error()
{
    $("#nota").val("Error");
}
