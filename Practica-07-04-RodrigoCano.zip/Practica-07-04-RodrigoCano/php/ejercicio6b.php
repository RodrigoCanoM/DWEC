<?php
$entrada=fopen('php://input','r');
$datos= fgets($entrada);
$datos= json_decode($datos,true);//Convierte el obj json en array
$resultado=array('marca'=>$datos['marca'],'elec'=>$datos['elec']);

$resultado["ancho"]=rand(20,60);
$resultado["alto"]=rand(10,30);
$resultado["fondo"]=rand(10,40);

$resultado=json_encode($resultado);//Convierte el array en obj json
echo $resultado;

?>