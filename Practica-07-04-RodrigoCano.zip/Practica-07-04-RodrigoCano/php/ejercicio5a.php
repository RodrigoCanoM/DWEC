<?php 

    header('Content-Type:text/xml');
    
    echo '<televisor>
            <marcas>
		        <marca>LG</marca>
			    <marca>Samsung</marca>
		        <marca>Panasonic</marca>
		        <marca>Philips</marca>
		   </marcas>	
		   <medidas>
               <medida>30</medida>
               <medida>40</medida>
               <medida>50</medida>
               <medida>60</medida>
           </medidas>	
		</televisor>';
		
?>