$(function(){
    cambio("txt/cantabria.txt");
})
function cambio(enlace){
    $("#contenido").load("http://localhost/js/Practica-07-04-RodrigoCano/1/"+ enlace);
}

