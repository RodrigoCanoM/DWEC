if (document.addEventListener)
	window.addEventListener("load",inicio)
else if (document.attachEvent)
	window.attachEvent("onload",inicio);

function inicio(){
	let formulario=document.getElementById("formulario");
	if (document.addEventListener)
		formulario.addEventListener("submit",validar)
	else if (document.attachEvent)
		formulario.attachEvent("onsubmit",validar);
	let cadena=document.cookie;
	if (cadena.length >= 0 ) {
		let posicion=cadena.indexOf("aficiones=");
		if (posicion!=-1) {
			if (posicion!=0)
				posicion=cadena.indexOf("; aficiones=");//Si hay mas de una cookie
			if (posicion!=-1){//verdadero mas de una cookie
				let pos2=cadena.indexOf("=",posicion+1); //Busca desde el anterior cookie
				let pos3=cadena.indexOf(";",pos2+1);// Busca el ; desde el igual para averiguar el valor
				if (pos3==-1) {//En caso de no encontrar el ; no hay una cookie despues()
					pos3=cadena.length;//como no hay ; despues , obtenemos el tamaño desd
				}
				let resultado= cadena.substring(pos2+1,pos3);//optiene todo los valores desde
				let conjuntoAficiones=resultado.split("$");//Cambia los $ por , de los valores ("leer$deporte") 
				//y lo convierte en array
				let aficiones=new Array("música","viajar","leer","deporte","fotos","videos","cenar","copas");
				let mensajesAficiones=new Array("Escuche el último disco de su grupo/cantante preferido.",
												"Lo ideal es un viaje al caribe.",
												"Lea el último libro de su escritor favorito.",
												"Siempre es bueno correr.",
												"Las mejores cámaras de fotos Nikon y Canon",
												"Grabe sus videos con las cámaras rápidas de 5000 fps",
												"Vaya a un restaurante con estrella Michelin.",
												"Si bebes no conduzcas.");
				let indice=0;
				let segundo=aficiones.indexOf(conjuntoAficiones[indice]);
				document.getElementById("mensajesAficiones").textContent=mensajesAficiones[segundo];
				indice+=1;
				setInterval(function() {//---------------Importante
					let segundo=aficiones.indexOf(conjuntoAficiones[indice]);
					document.getElementById("mensajesAficiones").textContent=mensajesAficiones[segundo];
					indice= (indice + 1) % conjuntoAficiones.length;//hacer un if (indice==conjuntoAficiones.length) indice = 0;

																			//indice++;
				},15000);//15000/1000= 15 segundos
			}
		}
	}

}

var letrasAdicionales="áéíóúüñ";

function validar(evento){
	let tiposVia= new Array("Calle","Plaza", "Camino", "Avenida" , "Plazuela" , "Bulevar" , "Carretera" , "Paseo" , "Travesía");
	let enviar=true;
	let etiquetaError=document.getElementsByClassName("errorformu");
	for (let i=0;i< etiquetaError.length;i++)
		etiquetaError.item(i).textContent="";
	let valorApellidos=document.getElementById("ape").value.trim().toLowerCase();
	if (!valildarApellidos(valorApellidos)){
		enviar=false;
		document.getElementById("errape").textContent="Error Apellidos, no tiene el formato deseado";
	}
	let valorNombre=document.getElementById("nomb").value.trim().toLowerCase();
	if (!validarNombre(valorNombre)){
		enviar=false;
		document.getElementById("errnomb").textContent="Error Nombre, no tiene el formato deseado";
	}
	let valorTipoVia=document.getElementById("tip").value.trim();
	let posit=tiposVia.indexOf(valorTipoVia);
	if (posit<0){
		enviar=false;
		document.getElementById("errtip").textContent="Error Tipo de Via, no tiene uno de los valores posibles";
	}
	let valorVia=document.getElementById("via").value.trim().toLowerCase();
	if (!validarVia(valorVia)){
		enviar=false;
		document.getElementById("errvia").textContent="Error Nombre de la Via, no tiene el formato deseado";
	}
	let valorNumero=document.getElementById("num").value.trim().toLowerCase();
	if (!validarNumero(valorNumero)){
		enviar=false;
		document.getElementById("errnum").textContent="Error Número, no tiene un valor adecuado";
	}
	let valorPortal=document.getElementById("por").value.trim().toLowerCase();
	if (!validarPortal(valorPortal)){
		enviar=false;
		document.getElementById("errpor").textContent="Error Portal, no tiene un valor adecuado";
	}
	let valorPiso=document.getElementById("piso").value.trim().toLowerCase();
	if (!validarPiso(valorPiso)){
		enviar=false;
		document.getElementById("errpiso").textContent="Error Piso, no tiene un valor adecuado";
	}
	let valorPuerta=document.getElementById("puer").value.trim().toLowerCase();
	if (!validarPuerta(valorPuerta)){
		enviar=false;
		document.getElementById("errpuer").textContent="Error Puerta, no tiene un valor adecuado";
	}
	let valorLocalidad=document.getElementById("loc").value.trim().toLowerCase();
	if (!validarLocalidad(valorLocalidad)){
		enviar=false;
		document.getElementById("errloc").textContent="Error Localidad, no tiene un valor adecuado";
	}
	let valorCodPos=document.getElementById("cp").value.trim().toLowerCase();
	if (!validarCodPos(valorCodPos)){
		enviar=false;
		document.getElementById("errcp").textContent="Error Código Postal, no tiene un valor adecuado";
	}
	let valorProvincia=document.getElementById("prov").value.trim().toLowerCase();
	if (!validarProvincia(valorProvincia)){
		enviar=false;
		document.getElementById("errprov").textContent="Error Código Postal, no tiene un valor adecuado";
	}
	let valorPais=document.getElementById("pas").value.trim().toLowerCase();
	if (!validarPais(valorPais)){
		enviar=false;
		document.getElementById("errpas").textContent="Error País o Estado, no tiene un valor adecuado";
	}
	let valorPuesto=document.getElementById("puesto").value.trim().toLowerCase();
	if (!validarPuesto(valorPuesto)){
		enviar=false;
		document.getElementById("errpuesto").textContent="Error Puesto de Trabajo, no tiene un valor adecuado";
	}
	let valorEmpresa=document.getElementById("empre").value.trim().toLowerCase();
	if (!validarEmpresa(valorEmpresa)){
		enviar=false;
		document.getElementById("errempre").textContent="Error Nombre de la Empresa, no tiene un valor adecuado";
	}
	let valorCategoria=document.getElementById("cate").value.trim().toLowerCase();
	if (!validarCategoria(valorCategoria)){
		enviar=false;
		document.getElementById("errcate").textContent="Error Nombre de la Empresa, no tiene un valor adecuado";
	}
	let numeroAficiones=0;
	let valorAficion="";
	if (document.getElementById("musica").checked){
		numeroAficiones+=1;
		valorAficion+="musica$";
	}
	if (document.getElementById("viajar").checked){
		numeroAficiones+=1;
		valorAficion+="viajar$";
	}
	if (document.getElementById("leer").checked){
		numeroAficiones+=1;
		valorAficion+="leer$";
	}
	if (document.getElementById("deporte").checked){
		numeroAficiones+=1;
		valorAficion+="deporte$";
	}	
	if (document.getElementById("fotos").checked){
		numeroAficiones+=1;
		valorAficion+="fotos$";
	}
	if (document.getElementById("videos").checked){
		numeroAficiones+=1;
		valorAficion+="videos$";
	}
	if (document.getElementById("cenar").checked){
		numeroAficiones+=1;
		valorAficion+="cenar$";
	}
	if (document.getElementById("copas").checked){
		numeroAficiones+=1;
		valorAficion+="copas$";
	}	
	if (numeroAficiones< 3)
		enviar=false
	console.log(enviar);
	if (!enviar)
		evento.preventDefault()
	else{
		valorAficion=valorAficion.substr(0,valorAficion.length -1);
		document.cookie="aficiones="+valorAficion + ";expires=true, 30 Jan 2030 00:00:00 GMT;";
	}
}
function valildarApellidos(datoApellido){
	let correcto= true;
	if (datoApellido.length < 7)
		correcto=false
	else {
		if (datoApellido.charAt(0) < "a" ||datoApellido.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoApellido.charAt(0)))
				correcto=false;
		if (datoApellido.charAt(datoApellido.length -1) < "a" ||datoApellido.charAt(datoApellido.length -1) > "z")
			if (!letrasAdicionales.includes(datoApellido.charAt(datoApellido.length -1)))
				correcto=false;	
		for (let i=1;i < datoApellido.length -1;i++)
			if (datoApellido.charAt(i) < "a" ||datoApellido.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoApellido.charAt(i)))
					if (datoApellido.charAt(i) != " " && datoApellido.charAt(i) != "-")
						correcto=false;
	}
	return correcto;
}

function validarNombre(datoNombre){
	let correcto=true;
	let adicionales=" ºª."
	if (datoNombre.length < 3 || datoNombre.length > 30)
		correcto=false
	else {
		if (datoNombre.charAt(0) < "a" ||datoNombre.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoNombre.charAt(0)))
				correcto=false;
		if (datoNombre.charAt(datoNombre.length -1) < "a" ||datoNombre.charAt(datoNombre.length -1) > "z")
			if (!letrasAdicionales.includes(datoNombre.charAt(datoNombre.length -1)))
				correcto=false;
		for (let i=1;i < datoNombre.length -1; i++)
			if (datoNombre.charAt(i) < "a" ||datoNombre.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoNombre.charAt(i)))
					if (!adicionales.includes(datoNombre.charAt(i)))
						correcto=false;
	}
	return correcto;
}

function validarVia(datoVia){
	let correcto=true;
	if (datoVia.length  < 3 ||datoVia.length > 35)
		correcto=false
	else {
		if (datoVia.charAt(0) < "a" ||datoVia.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoVia.charAt(0)))
				correcto=false;
		if (datoVia.charAt(datoVia.length -1) < "a" ||datoVia.charAt(datoVia.length -1) > "z")
			if (!letrasAdicionales.includes(datoVia.charAt(datoVia.length -1)))
				correcto=false;
		for (let i=1;i < datoVia.length -1; i++)
			if (datoVia.charAt(i) < "a" ||datoVia.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoVia.charAt(i)) && datoVia.charAt(i) != " ")
					correcto=false;
	}
	return correcto;
}

function  validarNumero(datoNumero){
	let correcto = true;
	if (datoNumero!="" && datoNumero!="s/n"){
		for (let i=0; i < datoNumero.length;i++)
			if (datoNumero.charAt(i)< "0" || datoNumero.charAt(i) > "9")
				correcto=false;
	}
	return correcto;
}

function validarPortal(datoPortal){
	let correcto=true;
	if (datoPortal!=""){
		for (let i=0;i<datoPortal.length;i++)
			if ( datoPortal.charAt(i) < "a" || datoPortal.charAt(i) > "z")
				if (datoPortal.charAt(i) < "0" || datoPortal.charAt(i) > "9" )
					if (!letrasAdicionales.includes(datoPortal.charAt(i)))
						correcto=false;
	}
	return correcto;
}

function validarPiso(datoPiso){
	let correcto=true;
	if (datoPiso!="")
		for (let i=0;i < datoPiso.length;i++)
			if (datoPiso.charAt(i) < "0" || datoPiso.charAt(i)  > "9")
				correcto=false;
	return correcto;
}

function validarPuerta(datoPuerta){
	let correcto=true;
	if (datoPuerta!=""){
		for (let i=0;i<datoPuerta.length;i++)
			if ( datoPuerta.charAt(i) < "a" || datoPuerta.charAt(i) > "z")
				if (datoPuerta.charAt(i) < "0" || datoPuerta.charAt(i) > "9" )
					if (!letrasAdicionales.includes(datoPuerta.charAt(i)))
						correcto=false;
	}
	return correcto;
}

function validarLocalidad(datoLocalidad){
	let correcto=true;
	if (datoLocalidad.length < 3 || datoLocalidad.length > 40)
		correcto=false
	else {
		if (datoLocalidad.charAt(0) < "a" ||datoLocalidad.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoLocalidad.charAt(0)))
						correcto=false;
		if (datoLocalidad.charAt(datoLocalidad.length -1) < "a" ||datoLocalidad.charAt(datoLocalidad.length -1) > "z")
			if (!letrasAdicionales.includes(datoLocalidad.charAt(datoLocalidad.length -1)))
						correcto=false;
		for (let i=0;i< datoLocalidad.length - 1 ; i++)
			if (datoLocalidad.charAt(i) < "a" ||datoLocalidad.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoLocalidad.charAt(i)) && datoLocalidad.charAt(i) !=" ")
						correcto=false;
	}
	return correcto;
}

function validarCodPos(datoCodPos){
	let correcto=true;
	if (datoCodPos.length < 4 ||datoCodPos.length > 5)
		correcto=false
	else {
		for (i=0;i < datoCodPos.length;i++)
			if (datoCodPos.charAt(i) < "0" || datoCodPos.charAt(i) > "9")
				correcto=false;
		if (correcto){
			let valCP=parseInt(datoCodPos,10);
			if (valCP< 1000 || valCP >=53000)
				correcto=false;
		}
	}
	return correcto;
}

function validarProvincia(datoProvincia){
	let correcto=true;
	if (datoProvincia.length < 6 || datoProvincia.length > 32)
		correcto=false
	else {
		if (datoProvincia.charAt(0) < "a" ||datoProvincia.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoProvincia.charAt(0)))
						correcto=false;
		if (datoProvincia.charAt(datoProvincia.length -1) < "a" ||datoProvincia.charAt(datoProvincia.length -1) > "z")
			if (!letrasAdicionales.includes(datoProvincia.charAt(datoProvincia.length -1)))
						correcto=false;
		for (let i=0;i< datoProvincia.length - 1 ; i++)
			if (datoProvincia.charAt(i) < "a" ||datoProvincia.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoProvincia.charAt(i)) && datoProvincia.charAt(i) !=" ")
						correcto=false;
	}
	return correcto;
}

function validarPais(datoPais){
	let correcto=true;
	if (datoPais.length < 8 || datoPais.length > 28)
		correcto=false
	else {
		if (datoPais.charAt(0) < "a" ||datoPais.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoPais.charAt(0)))
						correcto=false;
		if (datoPais.charAt(datoPais.length -1) < "a" ||datoPais.charAt(datoPais.length -1) > "z")
			if (!letrasAdicionales.includes(datoPais.charAt(datoPais.length -1)))
						correcto=false;
		for (let i=0;i< datoPais.length - 1 ; i++)
			if (datoPais.charAt(i) < "a" ||datoPais.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoPais.charAt(i)) && datoPais.charAt(i) !=" ")
						correcto=false;
	}
	return correcto;
}

function validarPuesto(datoPuesto){
	let correcto=true;
	if (datoPuesto.length < 10 || datoPuesto.length > 25)
		correcto=false
	else {
		let addicion="0123456789 -";
		if (datoPuesto.charAt(0) < "a" ||datoPuesto.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoPuesto.charAt(0)))
						correcto=false;
		if (datoPuesto.charAt(datoPuesto.length -1) < "a" ||datoPuesto.charAt(datoPuesto.length -1) > "z")
			if (!letrasAdicionales.includes(datoPuesto.charAt(datoPuesto.length -1)))
						correcto=false;
		for (let i=0;i< datoPuesto.length - 1 ; i++)
			if (datoPuesto.charAt(i) < "a" ||datoPuesto.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoPuesto.charAt(i)) && !addicion.includes(datoPuesto.charAt(i)))
						correcto=false;
	}
	return correcto;
}

function validarEmpresa(datoEmpresa){
	let correcto=true;
	if (datoEmpresa.length < 10 || datoEmpresa.length > 25)
		correcto=false
	else {
		let addicion="0123456789 -.";
		if (datoEmpresa.charAt(0) < "a" ||datoEmpresa.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoEmpresa.charAt(0)))
						correcto=false;
		if (datoEmpresa.charAt(datoEmpresa.length -1) < "a" ||datoEmpresa.charAt(datoEmpresa.length -1) > "z")
			if (!letrasAdicionales.includes(datoEmpresa.charAt(datoEmpresa.length -1)))
						correcto=false;
		for (let i=0;i< datoEmpresa.length - 1 ; i++)
			if (datoEmpresa.charAt(i) < "a" ||datoEmpresa.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoEmpresa.charAt(i)) && !addicion.includes(datoEmpresa.charAt(i)))
						correcto=false;
	}
	return correcto;
}

function validarCategoria(datoCategoria){
	let correcto=true;
	if (datoCategoria.length < 8 || datoCategoria.length > 20)
		correcto=false
	else {
		let addicion="0123456789 .";
		if (datoCategoria.charAt(0) < "a" ||datoCategoria.charAt(0) > "z")
			if (!letrasAdicionales.includes(datoCategoria.charAt(0)))
						correcto=false;
		if (datoCategoria.charAt(datoCategoria.length -1) < "a" ||datoCategoria.charAt(datoCategoria.length -1) > "z")
			if (!letrasAdicionales.includes(datoCategoria.charAt(datoCategoria.length -1)))
						correcto=false;
		for (let i=0;i< datoCategoria.length - 1 ; i++)
			if (datoCategoria.charAt(i) < "a" ||datoCategoria.charAt(i) > "z")
				if (!letrasAdicionales.includes(datoCategoria.charAt(i)) && !addicion.includes(datoCategoria.charAt(i)))
						correcto=false;
	}
	return correcto;
}

