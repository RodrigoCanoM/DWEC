if (document.addEventListener)
	window.addEventListener("load",inicio)
else if (document.attachEvent)
	window.attachEvent("onload",inicio);

var aficiones=new Array("música","viajar","leer","deporte","fotos","videos","cenar","copas");
var numeroAficiones=new Array(0,0,0,0,0,0,0,0)

function leerCookie(miaficion){
	let valor=0;
	let cadena=document.cookie;
	if (cadena.length >= 0 ) {
		let posicion=cadena.indexOf(miaficion+"=");
		if (posicion!=-1) {
			if (posicion!=0)
				posicion=cadena.indexOf("; "+miaficion+"=");
			if (posicion!=-1){
				let pos2=cadena.indexOf("=",posicion+1);
				let pos3=cadena.indexOf(";",pos2+1);
				if (pos3==-1) {
					pos3=cadena.length;
				}
				let resultado= cadena.substring(pos2+1,pos3);
				valor=parseInt(resultado,10);
			}
		}
	}
	return valor;
}

function inicio(){
	let formulario=document.getElementById("formulario");
	if (document.addEventListener)
		formulario.addEventListener("submit",validar)
	else if (document.attachEvent)
		formulario.attachEvent("onsubmit",validar);
	console.log(document.cookie);
	for (let i=0;i<aficiones.length;i++)
		numeroAficiones[i]=leerCookie(aficiones[i]);
}

var letrasAdicionales="áéíóúüñ";

function validar(evento){
	let enviar=true;
	let etiquetaError=document.getElementsByClassName("errorformu");
	for (let i=0;i< etiquetaError.length;i++)
		etiquetaError.item(i).textContent="";
	let valorApellidos=document.getElementById("ape").value.trim().toLowerCase();
	let expRegApellidos=/^[a-záéíóúñ][a-záéíóúñ \-]{5,}[a-záéíóúñ]$/i;
	if (!expRegApellidos.test(valorApellidos)){
		enviar=false;
		document.getElementById("errape").textContent="Error Apellidos, no tiene el formato deseado";
	}
	let valorNombre=document.getElementById("nomb").value.trim().toLowerCase();
	let expRegNombre=/^[a-záéíóúñ][a-záéíóúñ ºª\-]{1,28}[a-záéíóúñ]$/i;
	if (!expRegNombre.test(valorNombre)){
		enviar=false;
		document.getElementById("errnomb").textContent="Error Nombre, no tiene el formato deseado";
	}
	let valorTipoVia=document.getElementById("tip").value.trim();
	
	let expRegTipoVia=/^(Calle)|(Plaza)|(Camino)|(Avenida)|(Plazuela)|(Bulevar)|(Carretera)|(Paseo)|(Travesía)$/i;
	if (!expRegTipoVia.test(valorTipoVia)){
		enviar=false;
		document.getElementById("errtip").textContent="Error Tipo de Via, no tiene uno de los valores posibles";
	}
	let valorVia=document.getElementById("via").value.trim().toLowerCase();
	let expRegVia=/^[a-záéíóúñ][a-záéíóúñ ]{1,33}[a-záéíóúñ]$/i;
	if (!expRegVia.test(valorVia)){
		enviar=false;
		document.getElementById("errvia").textContent="Error Nombre de la Via, no tiene el formato deseado";
	}
	let valorNumero=document.getElementById("num").value.trim().toLowerCase();
	let expRegNumero=/^(\d*)|(s\/n)$/i;
	if (!expRegNumero.test(valorNumero)){
		enviar=false;
		document.getElementById("errnum").textContent="Error Número, no tiene un valor adecuado";
	}
	let valorPortal=document.getElementById("por").value.trim().toLowerCase();
	let expRegPortal=/^[a-záéíóúñ0-9]*$/i;
	if (!expRegPortal.test(valorPortal)){
		enviar=false;
		document.getElementById("errpor").textContent="Error Portal, no tiene un valor adecuado";
	}
	let valorPiso=document.getElementById("piso").value.trim().toLowerCase();
	let expRegPiso=/^\d*$/i;
	if (!expRegPiso.test(valorPiso)){
		enviar=false;
		document.getElementById("errpiso").textContent="Error Piso, no tiene un valor adecuado";
	}
	let valorPuerta=document.getElementById("puer").value.trim().toLowerCase();
	let expRegPuerta=/^[a-záéíóúñ0-9]*$/i;
	if (!expRegPuerta.test(valorPuerta)){
		enviar=false;
		document.getElementById("errpuer").textContent="Error Puerta, no tiene un valor adecuado";
	}
	let valorLocalidad=document.getElementById("loc").value.trim().toLowerCase();
	let expRegLocalidad=/^[a-záéíóúñ][a-záéíóúñ ]{1,38}[a-záéíóúñ]$/i;
	if (!expRegLocalidad.test(valorLocalidad)){
		enviar=false;
		document.getElementById("errloc").textContent="Error Localidad, no tiene un valor adecuado";
	}
	let valorCodPos=document.getElementById("cp").value.trim().toLowerCase();
	let expRegCodPos=/^((0?[1-9])|([1-4]\d)|(5[0-2]))\d{3}$/;
	if (!expRegCodPos.test(valorCodPos)){
		enviar=false;
		document.getElementById("errcp").textContent="Error Código Postal, no tiene un valor adecuado";
	}
	let valorProvincia=document.getElementById("prov").value.trim().toLowerCase();
	let expRegProvincia=/^[a-záéíóúñ][a-záéíóúñ ]{4,30}[a-záéíóúñ]$/i;
	if (!expRegProvincia.test(valorProvincia)){
		enviar=false;
		document.getElementById("errprov").textContent="Error Código Postal, no tiene un valor adecuado";
	}
	let valorPais=document.getElementById("pas").value.trim().toLowerCase();
	let expRegPais=/^[a-záéíóúñ][a-záéíóúñ ]{6,26}[a-záéíóúñ]$/i;
	if (!expRegPais.test(valorPais)){
		enviar=false;
		document.getElementById("errpas").textContent="Error País o Estado, no tiene un valor adecuado";
	}
	let valorPuesto=document.getElementById("puesto").value.trim().toLowerCase();
	let expRegPuesto=/^[a-záéíóúñ][a-záéíóúñ0-9 ]{8,23}[a-záéíóúñ]$/i;
	if (!expRegPuesto.test(valorPuesto)){
		enviar=false;
		document.getElementById("errpuesto").textContent="Error Puesto de Trabajo, no tiene un valor adecuado";
	}
	let valorEmpresa=document.getElementById("empre").value.trim().toLowerCase();
	let expRegEmpresa=/^[a-záéíóúñ][a-záéíóúñ0-9 \.\-]{4,23}[a-záéíóúñ]$/i;
	if (!expRegEmpresa.test(valorEmpresa)){
		enviar=false;
		document.getElementById("errempre").textContent="Error Nombre de la Empresa, no tiene un valor adecuado";
	}
	let valorCategoria=document.getElementById("cate").value.trim().toLowerCase();
	let expRegCategoria=/^[a-záéíóúñ][a-záéíóúñ0-9 \.]{6,18}[a-záéíóúñ]$/i;
	if (!expRegCategoria.test(valorCategoria)){
		enviar=false;
		document.getElementById("errcate").textContent="Error Nombre de la Empresa, no tiene un valor adecuado";
	}
	let numeroAficion=0;
	if (document.getElementById("musica").checked){
		numeroAficiones[0]+=1;
		numeroAficion+=1;
	}
	if (document.getElementById("viajar").checked){
		numeroAficiones[1]+=1;
		numeroAficion+=1;
	}
	if (document.getElementById("leer").checked){
		numeroAficiones[2]+=1;
		numeroAficion+=1;
	}
	if (document.getElementById("deporte").checked){
		numeroAficiones[3]+=1;	
		numeroAficion+=1;
	}
	if (document.getElementById("fotos").checked){
		numeroAficiones[4]+=1;
		numeroAficion+=1;
	}
	if (document.getElementById("videos").checked){
		numeroAficiones[5]+=1;
		numeroAficion+=1;
	}
	if (document.getElementById("cenar").checked){
		numeroAficiones[6]+=1;
		numeroAficion+=1;
	}
	if (document.getElementById("copas").checked){
		numeroAficiones[7]+=1;
		numeroAficion+=1;
	}
	if (numeroAficion< 3)
		enviar=false
	if (!enviar)
		evento.preventDefault()
	else{
		for (let i=0; i< aficiones.length;i++)
			if (numeroAficiones[i] > 0)
			document.cookie=aficiones[i]+"="+numeroAficiones[i] + ";expires=true, 30 Jan 2030 00:00:00 GMT;";
	}
	console.log(document.cookie);
}


